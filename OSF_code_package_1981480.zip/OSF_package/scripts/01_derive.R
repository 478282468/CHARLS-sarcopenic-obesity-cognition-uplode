# =============================================================
# 01_derive.R — 重建分析数据集(大修版)
# 目标:复现原稿样本流程 N=12,363;四表型 6369/1054/4524/416
# 数据源:~/Documents/ch/charls.csv (Harmonized CHARLS W1-W5)
# 本次分析只用 W1-W4 (2011-2018),与原稿一致
# 输出:derived.RData + 01_validation_report.txt
# =============================================================
suppressMessages(library(data.table))
setwd("/Users/liyanjiao/Documents/ch/修稿_Frontiers/pipeline")

dt <- fread("/Users/liyanjiao/Documents/ch/charls.csv")
setnames(dt, sub(" [(].*[)]$", "", names(dt)))   # 去掉列名中文注解
dt[, ID := as.character(ID)]

## ---------- 时间轴:w1=2011,w2=2013,w3=2015,w4=2018 ----------
wtime <- c(`1`=0, `2`=2, `3`=4, `4`=7)
dt[, time := wtime[as.character(wave)]]

## ---------- 性别编码验证 ----------
cat("== ragender 分布 ==\n"); print(table(dt[wave==1]$ragender, useNA="ifany"))
cat("按性别的握力均值(验证 0=女,1=男):")
print(dt[wave==1, .(mean_grip=round(mean(gripsum, na.rm=TRUE),1)), by=ragender])

## ---------- 1. 基线(W1)筛选 ----------
w1 <- dt[wave == 1]
flow <- c("W1 受访" = nrow(w1))

# (0) 年龄>=45
s <- w1[age >= 45]
flow["  年龄>=45"] <- nrow(s)

# (1) 基线记忆相关疾病排除 (memrye==1)
s <- s[is.na(memrye) | memrye == 0]
flow["  排除:基线记忆疾病"] <- nrow(s)

# (2) 精神疾病排除 (psyche==1)
s <- s[is.na(psyche) | psyche == 0]
flow["  排除:精神疾病"] <- nrow(s)

# (3) 卒中排除 (stroke==1)
s <- s[is.na(stroke) | stroke == 0]
flow["  排除:卒中"] <- nrow(s)

# (4) BMI 合理范围 10-60
s <- s[!is.na(bmi) & bmi >= 10 & bmi <= 60]
flow["  BMI 合理(10-60)且非缺失"] <- nrow(s)

# (5) 握力合理 0-80(原稿:<0 或 >80 排除;先按 gripsum)
s1 <- s[!is.na(gripsum) & gripsum >= 0 & gripsum <= 80]
s2 <- s[!is.na(rgrip) & !is.na(lgrip) &
        pmax(rgrip, lgrip) >= 0 & pmax(rgrip, lgrip) <= 80]
cat(sprintf("\n握力可用样本: gripsum=%d | max(rgrip,lgrip)=%d\n", nrow(s1), nrow(s2)))

# (6) 2011-2018 至少完成一次认知评估(W1-W4 任一波 total_cognition 非缺失)
cog_any <- dt[wave <= 4 & !is.na(total_cognition), unique(ID)]
s1 <- s1[ID %in% cog_any]; s2 <- s2[ID %in% cog_any]
flow["  >=1次认知评估(2011-2018)"] <- nrow(s1)
cat(sprintf("最终 N:gripsum 方案=%d | max双手 方案=%d  (目标 12363)\n", nrow(s1), nrow(s2)))

## ---------- 2. 表型定义 ----------
mk_pheno <- function(base, gripvar) {
  b <- copy(base)
  b[, grip := gripvar]
  b[, ow   := bmi >= 24]
  b[, sarc := fifelse(ragender == 1, grip < 28, grip < 18)]
  b[, pheno := fcase(!ow & !sarc, "NONS", !ow & sarc, "NS",
                      ow & !sarc, "ONS", ow & sarc, "OS")]
  b
}
bA <- mk_pheno(s1, s1$gripsum)
bB <- mk_pheno(s2, pmax(s2$rgrip, s2$lgrip))

cat("\n== 表型分布 vs 目标 (NONS 6369 / NS 1054 / ONS 4524 / OS 416) ==\n")
cat("方案A gripsum:\n");  print(bA[, .N, by=pheno][order(pheno)])
cat("方案B max双手:\n");  print(bB[, .N, by=pheno][order(pheno)])

## ---------- 3. 选择与目标更接近的方案,输出验证报告 ----------
distA <- sum(abs(bB[, .N, by=pheno][order(pheno)]$N - c(416,6369,4524,1054))) # 排序对齐见下
tabA <- bA[, .N, by=pheno][order(pheno)]$N
tabB <- bB[, .N, by=pheno][order(pheno)]$N
target <- sort(c(6369, 1054, 4524, 416))
cat(sprintf("\n方案A 差值合计=%d | 方案B 差值合计=%d\n",
    sum(abs(sort(tabA)-target)), sum(abs(sort(tabB)-target))))

base <- if (sum(abs(sort(tabA)-target)) <= sum(abs(sort(tabB)-target))) bA else bB
cat("\n==> 采用方案:", if (identical(base, bA)) "gripsum" else "max双手", "\n")

## ---------- 4. 教育变量(原稿版 vs 修正版) ----------
base[, educ4 := raeduc_c]                      # 修正版 4 分类:1无 2小学 3初中 4高中+
base[, educ3_h := raeducl]                     # 原稿疑似用法(标签错位)
cat("\n== 教育:各方案 <=小学 比例(原稿报告 98.5%) ==\n")
cat(sprintf("raeduc_c∈{1,2}(无+小学)      : %.1f%%\n", 100*mean(base$educ4 %in% c(1,2), na.rm=TRUE)))
cat(sprintf("raeducl==1 (<初中)           : %.1f%%\n", 100*mean(base$educ3_h == 1, na.rm=TRUE)))
cat(sprintf("raeducl∈{1,2} (非大学)       : %.1f%%\n", 100*mean(base$educ3_h %in% c(1,2), na.rm=TRUE)))
cat("raeduc_c 分布:\n"); print(base[, .N, by=educ4][order(educ4)])

## ---------- 5. 认知结局长表(W1-W4) ----------
ids <- base$ID
cog <- dt[wave <= 4 & ID %in% ids,
          .(ID, wave, time, recall, exec = executive, total = total_cognition)]
cat("\n认知长表行数:", nrow(cog), " 人次:", uniqueN(cog$ID), "\n")

## ---------- 6. 认知障碍切点(原稿版/修正版) ----------
# 原稿:total <10(≤小学)/<13(≥初中);其教育编码疑似 raeducl∈{1,2}=≤小学
cog <- merge(cog, base[, .(ID, educ4, educ3_h)], by = "ID", all.x = TRUE)
cog[, imp_orig := total < fifelse(educ3_h %in% c(1,2) | is.na(educ3_h), 10, 13)]
cog[, imp_fix  := total < fifelse(educ4 %in% c(1,2)       | is.na(educ4),  10, 13)]
cat("\n== 基线认知障碍人数(目标:12363-9264=3099) ==\n")
b_imp <- cog[wave == 1]
cat(sprintf("原稿切点(raeducl 1/2→<10): %d (%.1f%%)\n",
    sum(b_imp$imp_orig, na.rm=TRUE), 100*mean(b_imp$imp_orig, na.rm=TRUE)))
cat(sprintf("原稿切点(raeducl==1→<10) : %d (%.1f%%)\n",
    sum(b_imp$imp_orig2 <- b_imp$total < fifelse(b_imp$educ3_h==1 | is.na(b_imp$educ3_h), 10, 13), na.rm=TRUE),
    100*mean(b_imp$total < fifelse(b_imp$educ3_h==1 | is.na(b_imp$educ3_h), 10, 13), na.rm=TRUE)))
cat(sprintf("修正切点(raeduc_c 1/2→<10): %d (%.1f%%)\n",
    sum(b_imp$imp_fix, na.rm=TRUE), 100*mean(b_imp$imp_fix, na.rm=TRUE)))

## ---------- 7. 基线协变量 ----------
base[, chronic_n := rowSums(cbind(hibpe, dyslipe, diabe, cancre, lunge,
                                   hearte, stroke, livere, kidneye, digeste, asthmae) == 1, na.rm=TRUE)]
base[, chronic := fcase(chronic_n == 0, "0", chronic_n == 1, "1", default = "2+")]
base[, adl_dis := fifelse(!is.na(adlab_c) & adlab_c > 0, 1L, 0L)]
base[, logcons := log(hhcperc + 1)]

## ---------- 8. Table 1 关键指标对照 ----------
cat("\n== Table 1 验证(目标:age 59.1±9.4 | 女 52.6% | grip 31.8±10.7 | BMI 23.5±3.9 |
    global 10.7±4.4 | episodic 3.6±1.7 | mental 8.1±2.6) ==\n")
t1 <- base[, .(
  N = .N,
  age_mean = round(mean(age),1), age_sd = round(sd(age),1),
  female = round(100*mean(ragender==0),1),
  grip_mean = round(mean(grip),1), grip_sd = round(sd(grip),1),
  bmi_mean = round(mean(bmi),1), bmi_sd = round(sd(bmi),1),
  global = round(mean(total_cognition, na.rm=TRUE),1),
  episodic = round(mean(recall, na.rm=TRUE),1),
  mental = round(mean(executive, na.rm=TRUE),1)
)]
print(t1)

## ---------- 9. 死亡信息 ----------
dinfo <- unique(dt[!is.na(radyear), .(ID, radyear, radmonth)])
setnames(dinfo, c("ID","radyear","radmonth"), c("ID","dyear","dmonth"))

## ---------- 10. 保存 ----------
save(base, cog, dinfo, flow, file = "derived.RData")
writeLines(capture.output({
  cat("========== 01_derive 验证报告 ==========\n"); print(flow)
  cat("\n最终N:", nrow(base), "(目标 12363)\n")
  print(base[, .N, by=pheno][order(pheno)])
  print(t1)
}), "01_validation_report.txt")
cat("\n== 派生完成,结果已存 derived.RData ==\n")
