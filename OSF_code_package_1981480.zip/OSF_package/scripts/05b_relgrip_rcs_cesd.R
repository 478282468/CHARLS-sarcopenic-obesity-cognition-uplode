# =============================================================
# 05b_relgrip_rcs_cesd.R — Major 4 / 8 / 10 新分析
# (1) 相对握力表型(FNIH 式 grip/BMI)→ 重定义表型 → LMM+Cox
# (2) 连续 BMI × 握力 RCS 交互(基线全局认知 + Cox)
# (3) 补调 CES-D 抑郁(cesd10)
# (4) time² 系数展示
# =============================================================
suppressMessages({library(data.table); library(lme4); library(survival); library(rms)})
setwd("/Users/liyanjiao/Documents/ch/修稿_Frontiers/pipeline")
load("derived_corrected.RData")

base[, pheno   := factor(pheno, levels = c("NONS","NS","ONS","OS"))]
base[, educ4f  := factor(educ4, levels = c(1,2,3,4))]
base[, marry_bin := fifelse(marry == 1, 1L, 0L)]
base[, chronicf := factor(chronic, levels = c("0","1","2+"))]

covars <- c("age","ragender","educ4f","marry_bin","region","hrural","rural2",
            "smokev","drinkl","work","retire","logcons","chronicf","adl_dis")

## ---------- (1) 相对握力表型 ----------
base[, relgrip := gripsum / bmi]
base[, relgrip_w := gripsum / mweight]          # grip/体重
base[, sarc_rel := fifelse(ragender == 1, relgrip < 1.20, relgrip < 0.53)]  # FNIH grip/BMI
base[, pheno_rel := fcase(bmi < 24 & !sarc_rel, "NONS", bmi < 24 & sarc_rel, "NS",
                           bmi >= 24 & !sarc_rel, "ONS", default = "OS")]
base[, pheno_rel := factor(pheno_rel, levels = c("NONS","NS","ONS","OS"))]
cat("== 相对握力(grip/BMI, FNIH切点)表型分布 ==\n")
print(base[, .N, by = pheno_rel][order(pheno_rel)])
cat(sprintf("与原表型一致率:%.1f%%\n\n", 100*mean(as.character(base$pheno) == as.character(base$pheno_rel), na.rm = TRUE)))

# 相对握力表型下的 LMM(global)
mk_long <- function(Lbase, yvar = "total") {
  L <- merge(cog2[, .(ID, ftime = time, y = get(yvar))], Lbase, by = "ID")
  L <- L[!is.na(y)]
  for (v in covars) L <- L[!is.na(get(v))]
  L
}
L <- mk_long(base)
L[, pheno_r := pheno_rel]
m_rel <- lmer(y ~ pheno_r * ftime + age + ragender + educ4f + marry_bin + region +
              hrural + rural2 + smokev + drinkl + work + retire + logcons +
              chronicf + adl_dis + (ftime | ID), data = L, REML = FALSE,
              control = lmerControl(optimizer = "bobyqa"))
fe <- fixef(m_rel); ci <- confint(m_rel, method = "Wald")
cat("== 相对握力表型 LMM(global)==\n")
for (p in c("NS","ONS","OS")) {
  n1 <- paste0("pheno_r", p); n2 <- paste0("pheno_r", p, ":ftime")
  cat(sprintf("  %-4s 基线 %+.3f (%+.3f,%+.3f) | 下降 %+.4f (%+.3f,%+.3f)\n",
      p, fe[[n1]], ci[n1,1], ci[n1,2], fe[[n2]], ci[n2,1], ci[n2,2]))
}

# 相对握力表型下的 Cox(用原 imp15 结局,重算事件)
sv <- readRDS("sv_imp15.rds"); sv <- merge(sv, base, by = "ID", all.x = TRUE)
mcov <- c("pheno_rel","age","ragender","educ4f","marry_bin","region","hrural","rural2",
          "smokev","drinkl","work","retire","logcons","chronicf","adl_dis")
svcc <- sv[complete.cases(sv[, ..mcov])]
m_rel_cox <- coxph(Surv(t, event) ~ pheno_rel + age + ragender + educ4f + marry_bin +
                   region + hrural + rural2 + smokev + drinkl + work + retire +
                   logcons + chronicf + adl_dis, data = svcc)
cf <- summary(m_rel_cox)$coefficients; ci <- confint(m_rel_cox)
cat("\n== 相对握力表型 Cox M4(−1.5SD 结局)==\n")
for (p in c("NS","ONS","OS")) {
  nm <- paste0("pheno_rel", p)
  cat(sprintf("  %-4s HR=%.3f (%.3f-%.3f) p=%.3f\n", p,
      exp(cf[nm,1]), exp(ci[nm,1]), exp(ci[nm,2]), cf[nm,5]))
}

## ---------- (2) RCS 交互 ----------
mcols <- c("y","bmi","gripsum", covars)
b1 <- merge(cog2[wave == 1, .(ID, y = total)], base, by = "ID")
b1 <- b1[complete.cases(b1[, ..covars]) & !is.na(y) & !is.na(gripsum) & !is.na(bmi), ..mcols]
dd2 <- datadist(b1); options(datadist = "dd2")
ols_r <- ols(y ~ rcs(bmi, 4) * rcs(gripsum, 4) + age + ragender + educ4f +
             marry_bin + region + hrural + rural2 + smokev + drinkl + work +
             retire + logcons + chronicf + adl_dis, data = b1)
cat("\n== (2a) 基线全局认知:RCS(bmi)×RCS(grip) 交互检验 ==\n")
print(anova(ols_r))

mcols2 <- c("t","event","bmi","gripsum", gsub("pheno_rel","pheno",mcov))
sv2 <- svcc[!is.na(gripsum) & !is.na(bmi), ..mcols2]
dd3 <- datadist(sv2); options(datadist = "dd3")
cph_r <- cph(Surv(t, event) ~ rcs(bmi, 4) + rcs(gripsum, 4) + age + ragender +
             educ4f + marry_bin + region + hrural + rural2 + smokev + drinkl +
             work + retire + logcons + chronicf + adl_dis, data = sv2, x = TRUE, y = TRUE)
cat("\n== (2b) Cox:连续 BMI 与握力的非线性检验 ==\n")
print(anova(cph_r))

## ---------- (3) 补调 CES-D ----------
sv3 <- sv[complete.cases(sv[, ..mcov]) & !is.na(cesd10)]
m_cesd <- coxph(Surv(t, event) ~ pheno + age + ragender + educ4f + marry_bin +
                region + hrural + rural2 + smokev + drinkl + work + retire +
                logcons + chronicf + adl_dis + cesd10, data = sv3)
cf <- summary(m_cesd)$coefficients; ci <- confint(m_cesd)
cat(sprintf("\n== (3) +CES-D10 Cox M4(N=%d,事件=%d)==\n", m_cesd$n, m_cesd$nevent))
for (p in c("NS","ONS","OS")) {
  nm <- paste0("pheno", p)
  cat(sprintf("  %-4s HR=%.3f (%.3f-%.3f) p=%.3f\n", p,
      exp(cf[nm,1]), exp(ci[nm,1]), exp(ci[nm,2]), cf[nm,5]))
}
cat(sprintf("  CES-D10(每分) HR=%.3f\n", exp(cf["cesd10",1])))

## ---------- (4) time² 系数 ----------
L2 <- copy(L); L2[, ft2 := ftime * ftime]
m_q <- lmer(y ~ pheno * (ftime + ft2) + age + ragender + educ4f + marry_bin +
            region + hrural + rural2 + smokev + drinkl + work + retire + logcons +
            chronicf + adl_dis + (ftime | ID), data = L2, REML = FALSE,
            control = lmerControl(optimizer = "bobyqa"))
fe <- fixef(m_q); ci <- confint(m_q, method = "Wald")
cat("\n== (4) time² 模型(global)==\n")
cat(sprintf("  ΔAIC vs 线性: %.1f\n", AIC(m_q) - AIC(
  lmer(y ~ pheno * ftime + age + ragender + educ4f + marry_bin + region + hrural +
       rural2 + smokev + drinkl + work + retire + logcons + chronicf + adl_dis +
       (ftime | ID), data = L, REML = FALSE, control = lmerControl(optimizer = "bobyqa")))))
for (p in c("NONS","NS","ONS","OS")) {
  n2 <- if (p == "NONS") "phenoNS:ft2" else paste0("pheno", p, ":ft2")
  nm2 <- if (p == "NONS") "ft2" else n2
  if (nm2 %in% names(fe)) cat(sprintf("  %-4s time² %+.4f (%+.4f,%+.4f)\n",
      p, fe[[nm2]], ci[nm2,1], ci[nm2,2]))
}
cat("== 05b 完成 ==\n")
