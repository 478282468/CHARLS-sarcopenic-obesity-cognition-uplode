# =============================================================
# 03_cox_reproduce.R — 复现 Table 3(Cox 模型,原稿切点)
# 事件:首次 t21 < 教育(<10/<13)切点;事件时间=两波中点
# 对照目标:ONS HR=0.906 (0.833-0.985) | NS=1.118 | OS=1.134
#           Model2: ONS 0.875, NS 1.200, OS 1.139
# =============================================================
suppressMessages({library(data.table); library(survival)})
setwd("/Users/liyanjiao/Documents/ch/修稿_Frontiers/pipeline")
load("derived.RData")

base[, pheno := factor(pheno, levels = c("NONS","NS","ONS","OS"))]
base[, educ3f := factor(educ3_h, levels = c(1,2,3))]
base[, marry_bin := fifelse(marry == 1, 1L, 0L)]
base[, chronicf := factor(chronic, levels = c("0","1","2+"))]

# ---------- 生存数据构造 ----------
w1cog <- cog[wave == 1, .(ID, t0 = total, educ3_h)]
surv <- data.table(ID = base$ID)
surv <- merge(surv, w1cog, by = "ID", all.x = TRUE)
# 原稿切点:educ3_h∈{1,2}→<10,else <13(NA按<10)
surv[, cut0 := fifelse(educ3_h %in% c(1,2) | is.na(educ3_h), 10, 13)]
surv <- surv[!is.na(t0)]
surv[, imp0 := t0 < cut0]
cat(sprintf("基线障碍 %d (%.1f%%) | 无障碍 %d  (手稿: 3099/9264)\n",
    sum(surv$imp0), 100*mean(surv$imp0), sum(!surv$imp0)))

risk <- surv[imp0 == FALSE]

# 每人各波认知与时间
cogsub <- cog[, .(ID, wave, time, total)]
setkey(cogsub, ID, wave)

mk_sv <- function(riskset) {
  out <- copy(riskset)
  out[, `:=`(event = 0L, t_event = NA_real_)]
  for (i in seq_len(nrow(out))) {
    id <- out$ID[i]
    w <- cogsub[ID == id]
    w <- w[wave >= 2 & !is.na(total)]
    prev <- 0                       # 基线无障碍
    ev <- 0; te <- w[wave == 1, max(time, 0)]
    last_t <- 0
    if (nrow(w) > 0) {
      for (r in seq_len(nrow(w))) {
        if (w$total[r] < out$cut0[i]) { ev <- 1L; te <- (last_t + w$time[r]) / 2; break }
        last_t <- w$time[r]
      }
      if (ev == 0) te <- last_t     # 未事件:删失于最后观测波
    } else te <- 0                  # 无随访认知:删失于0(将剔除)
    out$event[i] <- ev; out$t_event[i] <- te
  }
  out[t_event > 0]                  # 需要有观察时间
}

cat("构造生存数据(循环,约1-2分钟)...\n")
sv <- mk_sv(risk)
cat(sprintf("风险集 N=%d 事件=%d (%.1f%%)  (手稿: 9264/3355=36.2%%)\n",
    nrow(sv), sum(sv$event), 100*mean(sv$event)))

# 合并协变量
sv <- merge(sv, base, by = "ID")
m2 <- coxph(Surv(t_event, event) ~ pheno + age + ragender + educ3f + marry_bin +
            region + hrural + smokev + drinkl, data = sv)
m4 <- coxph(Surv(t_event, event) ~ pheno + age + ragender + educ3f + marry_bin +
            region + hrural + rural2 + smokev + drinkl + work + retire +
            logcons + chronicf + adl_dis, data = sv)

for (mn in c("m2","m4")) {
  m <- get(mn); s <- summary(m)
  cat(sprintf("\n[%s] N=%d 事件=%d\n", mn, m$nevent + 0, s$nevent))
  for (p in c("NS","ONS","OS")) {
    nm <- paste0("pheno", p)
    cat(sprintf("  %-4s HR=%.3f (%.3f-%.3f) p=%.3f\n", p,
        s$coefficients[nm,1], s$conf.low[nm], s$conf.high[nm], s$coefficients[nm,5]))
  }
}
cat("\n手稿 Model2: NS 1.200 ONS 0.875 OS 1.139 | Model4: NS 1.118 ONS 0.906 OS 1.134\n")
saveRDS(sv, "sv_original_cutoff.rds")
cat("== 完成 ==\n")
