# 09_imp10_cox.R — −1.0SD 结局的 Cox M4(敏感性)
suppressMessages({library(data.table); library(survival)})
setwd("/Users/liyanjiao/Documents/ch/修稿_Frontiers/pipeline")
load("derived_corrected.RData")
base[, pheno := factor(pheno, levels = c("NONS","NS","ONS","OS"))]
base[, educ4f := factor(educ4, levels = c(1,2,3,4))]
base[, marry_bin := fifelse(marry == 1, 1L, 0L)]
base[, chronicf := factor(chronic, levels = c("0","1","2+"))]
## 构造 imp10 事件数据(与 04 mk_surv 相同逻辑)
w1 <- cog2[wave == 1, .(ID, imp0 = imp10)]
risk <- base[ID %in% w1[is.na(imp0) | imp0 == FALSE, ID]]
setkey(cog2, ID, wave)
ev <- rbindlist(lapply(risk$ID, function(id) {
  w <- cog2[ID == id & wave >= 2 & !is.na(imp10)]
  prev <- 0L; e <- 0L; te <- 0; last_t <- cog2[ID == id & wave == 1, max(time, 0)]
  for (r in seq_len(nrow(w))) {
    if (isTRUE(as.logical(w$imp10[r]))) { e <- 1L; te <- (last_t + w$time[r]) / 2; break }
    last_t <- w$time[r]
  }
  if (e == 0) { obs <- cog2[ID == id & !is.na(total)]; te <- if (nrow(obs)) max(obs$time, 0) else 0 }
  data.table(ID = id, event = e, t = te)
}))
sv <- merge(ev[t > 0], base, by = "ID")
for (v in c("age","ragender","educ4f","marry_bin","region","hrural","rural2","smokev",
            "drinkl","work","retire","logcons","chronicf","adl_dis")) sv <- sv[!is.na(get(v))]
f <- "Surv(t, event) ~ pheno + age + ragender + educ4f + marry_bin + region + hrural + rural2 + smokev + drinkl + work + retire + logcons + chronicf + adl_dis"
m <- coxph(as.formula(f), data = sv)
cf <- as.data.frame(summary(m)$coefficients); ci <- confint(m)
out <- capture.output({
  cat(sprintf("== −1.0SD 结局 Cox M4: N=%d 事件=%d (%.1f%%)==\n", m$n, m$nevent, 100*m$nevent/m$n))
  for (p in c("NS","ONS","OS")) {
    nm <- paste0("pheno", p)
    cat(sprintf("  %-4s HR=%.3f (%.3f-%.3f) p=%.4g\n", p,
        exp(cf[nm,"coef"]), exp(ci[nm,1]), exp(ci[nm,2]), cf[nm,"Pr(>|z|)"]))
  }
})
writeLines(out, "09_imp10_report.txt")
cat(out, sep = "\n")
