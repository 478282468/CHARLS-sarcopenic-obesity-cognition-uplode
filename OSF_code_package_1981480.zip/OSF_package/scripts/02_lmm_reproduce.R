# =============================================================
# 02_lmm_reproduce.R — 复现 Table 2A/2B(线性混合模型)
# 模型:y ~ pheno * ftime + 协变量 + (time|ID),complete-case
# 教育协变量:先用原稿的 raeducl 3分类(复现),后用修正 raeduc_c(修正版)
# 对照目标(Table 2A 基线 / 2B 下降率):
#   NS:  global -0.990 / ×time -0.0634 ; episodic -0.177 / -0.0566 ; mental -0.524 / -0.0030
#   ONS: global +0.299 / +0.0556       ; episodic +0.009 / +0.0354  ; mental +0.230 / +0.0070
#   OS:  global -0.651 / -0.0329       ; episodic -0.149 / -0.0098  ; mental -0.233 / 0.0000
# =============================================================
suppressMessages({library(data.table); library(lme4)})
setwd("/Users/liyanjiao/Documents/ch/修稿_Frontiers/pipeline")
load("derived.RData")

# ---------- 长表合并基线协变量 ----------
base[, pheno := factor(pheno, levels = c("NONS","NS","ONS","OS"))]
base[, educ3f := factor(educ3_h, levels = c(1,2,3))]
base[, educ4f := factor(educ4,   levels = c(1,2,3,4))]
base[, chronicf := factor(chronic, levels = c("0","1","2+"))]

base[, marry_bin := fifelse(marry == 1, 1L, 0L)]   # 1=已婚 vs 其他

covars <- c("age","ragender","educ3f","marry_bin","region","hrural","rural2",
            "smokev","drinkl","work","retire","logcons","chronicf","adl_dis")

mk_long <- function(yvar) {
  L <- merge(cog[, .(ID, ftime = time, y = get(yvar))], base, by = "ID")
  L <- L[!is.na(y)]
  for (v in covars) L <- L[!is.na(get(v))]
  L
}

fit_one <- function(L) {
  lmer(y ~ pheno * ftime + age + ragender + educ3f + marry_bin + region + hrural +
       rural2 + smokev + drinkl + work + retire + logcons + chronicf + adl_dis +
       (ftime | ID), data = L, REML = FALSE,
       control = lmerControl(optimizer = "bobyqa"))
}

extract_pe <- function(m) {
  fe <- fixef(m); ci <- confint(m, method = "Wald")
  out <- list()
  for (p in c("NS","ONS","OS")) {
    for (term in c("main","slope")) {
      nm <- if (term == "main") paste0("pheno", p) else paste0("pheno", p, ":ftime")
      out[[paste(p, term)]] <- sprintf("%+.3f (%+.3f, %+.3f)",
        fe[[nm]], ci[nm,1], ci[nm,2])
    }
  }
  out
}

res <- list()
for (yn in c("global","episodic","mental")) {
  yv <- switch(yn, global="total", episodic="recall", mental="exec")
  L <- mk_long(yv)
  cat(sprintf("\n[%s] complete-case 行数=%d 人数=%d\n", yn, nrow(L), uniqueN(L$ID)))
  m <- fit_one(L)
  pe <- extract_pe(m)
  res[[yn]] <- pe
  for (k in names(pe)) cat(sprintf("  %-12s %s\n", k, pe[[k]]))
  saveRDS(m, file = paste0("fit_lmm_", yn, "_educ3.rds"))
}

cat("\n===== 对照手稿 Table 2 =====\n")
cat("NS  global main 目标 -0.990 | slope 目标 -0.063\n")
cat("ONS global main 目标 +0.299 | slope 目标 +0.056\n")
cat("OS  global main 目标 -0.651 | slope 目标 -0.033\n")
saveRDS(res, "lmm_educ3_results.rds")
cat("\n== 完成 ==\n")
