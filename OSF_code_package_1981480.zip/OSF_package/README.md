# Analytic Code for: Probable Sarcopenic Obesity Phenotypes and Cognitive Aging in Chinese Adults

## Overview

This repository contains the complete R analysis pipeline used in the revised manuscript. All analyses were performed in R 4.6.0 with the packages `data.table`, `lme4`, `survival`, `icenReg`, `rms`, `cmprsk`, and `ggplot2`.

## Data access

The analysis uses the harmonized China Health and Retirement Longitudinal Study (CHARLS) dataset. **Individual-level data are NOT included in this repository**; CHARLS data are publicly available to all researchers upon registration and signing a data use agreement at http://charls.pku.edu.cn/. Place the analysis extract as `charls.csv` in the working directory (405 variables × 96,628 person-wave rows × 5 waves) and set the working paths in each script.

## Pipeline (run in order)

| Script | Purpose |
|---|---|
| `00b_derive_corrected.R` | Derives the analytic dataset: sample flow (N = 17,708 → 12,152), phenotypes (BMI × AWGS grip), corrected education (raeduc_c), norm-based cognitive impairment cutoffs (age × education strata, −1.5 SD / −1.0 SD), missingness table |
| `01_derive.R` | Original reproduction derivation (used to audit the submitted version; documents the education miscoding) |
| `02_lmm_reproduce.R` | Reproduces original Table 2 (LMM, original education coding) |
| `03_cox_reproduce.R` | Reproduces original Table 3 (Cox, original cutoffs; audit trail) |
| `04_corrected_main.R` | **Main revised analyses**: corrected LMM (Tables 2A/2B), corrected Cox (Table 3, Models 2/4), reversion rate, two-consecutive-wave sensitivity |
| `05a_interval_age_cif.R` | Interval-censored Cox (icenReg), age-as-timescale Cox, Fine–Gray + CIF curves |
| `05b_relgrip_rcs_cesd.R` | Relative grip/BMI phenotypes (FNIH), restricted cubic spline analyses, CES-D adjustment, quadratic time term |
| `05c_ipw_missing_flow.R` | IPW attrition weighting, missingness/flow tables, physical-activity subgroup |
| `06_figures.R` | Publication figures: flow diagram, marginal cognitive trajectories, CIF curves |
| `07_gap_analyses.R` | Incremental value (LRT/C-index), FDR families, practice effects, phenotype transitions, time-varying Cox, flow table |
| `07b_interactions.R` | All 36 three-way interaction coefficients with 95% CIs |
| `07c_nri.R` | Continuous NRI (5-year) and calibration quintiles |
| `08_supplementary_sas.R` | WHO-criteria, merged-sarcopenia, reverse-causation (landmark / baseline-cognition / low-quintile exclusion) analyses and E-values |
| `09_imp10_cox.R` | Cox models under the 1.0 SD outcome definition |
| `10_tables_export.R` | Cox Models 1–4 full estimates and random-slope AIC/BIC comparison |
| `11_fig_fixes.R` | Revised flow diagram, CIF figure (risk-set Ns, Gray’s test), sensitivity forest plot |
| `12_relgrip_fnih.R` | Relative-strength (grip/BMI) phenotypes using the official FNIH cutoffs (1.00 men / 0.56 women) |

## Contents

- `scripts/` — the R scripts above
- `aggregate_results/` — aggregate outputs only (tables, figures): safe to share, contain no individual-level data

## Key definitions

- **Phenotypes**: BMI ≥24 kg/m² (Chinese WS/T 428-2013; WHO ≥25 in sensitivity) × probable sarcopenia (grip <28 kg men / <18 kg women, AWGS 2019)
- **Outcome**: global cognition (0–21) more than 1.5 SD below the age- (45–59/60–69/≥70) and education- (≤primary vs ≥middle) stratified baseline mean; −1.0 SD and two-consecutive-wave definitions in sensitivity analyses
- **Education covariate**: harmonized `raeduc_c` (no formal / primary / middle / high school+). *Note: the originally submitted version mistakenly relabeled the 3-level `raeducl` variable; this was corrected during revision (see Response to Reviewers).*

## Reproducibility notes

Model objects are not stored (size); rerunning the scripts regenerates all numbers reported in the manuscript and supplement. Randomness is limited to multiple-imputation seeding, which is fixed in the scripts.
