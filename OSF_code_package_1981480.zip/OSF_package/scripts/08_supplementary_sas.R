# =============================================================
# 08_supplementary_sas.R — 用修正数据重跑原稿剩余敏感性分析
#  1. WHO BMI 切点(>=25):LMM global 下降 + Cox M4
#  2. 合并肌少组(NS+OS):LMM global + Cox M4
#  3. 反向因果三件套:landmark 2年 / +基线认知 / 排除基线最低20%
#  4. E-values(NS/ONS/OS,M4)
# =============================================================
suppressMessages({library(data.table); library(lme4); library(survival)})
setwd("/Users/liyanjiao/Documents/ch/修稿_Frontiers/pipeline")
load("derived_corrected.RData")
sv15 <- readRDS("sv_imp15.rds")
out <- capture.output({

base[, pheno := factor(pheno, levels = c("NONS","NS","ONS","OS"))]
base[, educ4f := factor(educ4, levels = c(1,2,3,4))]
base[, marry_bin := fifelse(marry == 1, 1L, 0L)]
base[, chronicf := factor(chronic, levels = c("0","1","2+"))]
covars <- c("age","ragender","educ4f","marry_bin","region","hrural","rural2",
            "smokev","drinkl","work","retire","logcons","chronicf","adl_dis")

mk_long <- function(yv) {
  L <- merge(cog2[, .(ID, ftime = time, y = get(yv))], base, by = "ID")
  L <- L[!is.na(y)]; for (v in covars) L <- L[!is.na(get(v))]
  L
}
show_lmm <- function(m, tag) {
  cf <- as.data.frame(summary(m)$coefficients); ci <- confint(m, method = "Wald")
  pf <- function(t) 2*pnorm(-abs(t))
  cat(sprintf("\n[%s] N行=%d 人=%d\n", tag, nrow(m@frame), uniqueN(m@frame$ID)))
  for (p in c("NS","ONS","OS")) {
    n2 <- paste0("pheno", p, ":ftime")
    cat(sprintf("  %-4s 基线 %+.3f (%+.3f,%+.3f) | 下降 %+.4f (%+.3f,%+.3f) p=%.4g\n", p,
        cf[paste0("pheno",p),"Estimate"], ci[paste0("pheno",p),1], ci[paste0("pheno",p),2],
        cf[n2,"Estimate"], ci[n2,1], ci[n2,2], pf(cf[n2,"t value"])))
  }
}
run_cox <- function(d, tag, extra = NULL) {
  f <- paste("Surv(t, event) ~ pheno +", f_main0, if (!is.null(extra)) paste("+", extra) else "")
  m4 <- coxph(as.formula(f), data = d)
  cf <- as.data.frame(summary(m4)$coefficients); ci <- confint(m4)
  cat(sprintf("\n[%s] N=%d 事件=%d\n", tag, m4$n, m4$nevent))
  for (p in c("NS","ONS","OS")) {
    nm <- paste0("pheno", p)
    cat(sprintf("  %-4s HR=%.3f (%.3f-%.3f) p=%.4g\n", p,
        exp(cf[nm,"coef"]), exp(ci[nm,1]), exp(ci[nm,2]), cf[nm,"Pr(>|z|)"]))
  }
  invisible(m4)
}
f_main0 <- "age + ragender + educ4f + marry_bin + region + hrural + rural2 + smokev + drinkl + work + retire + logcons + chronicf + adl_dis"

cat("########## 1. WHO 切点(BMI>=25)##########\n")
baseW <- copy(base)
baseW[, ow := bmi >= 25]
baseW[, pheno := fcase(!ow & !(sarc), "NONS", !ow & sarc, "NS",
                        ow & !sarc, "ONS", default = "OS")]
baseW[, pheno := factor(pheno, levels = c("NONS","NS","ONS","OS"))]
cat("表型分布(WHO):"); print(baseW[, .N, by = pheno][order(pheno)])
Lg <- merge(cog2[, .(ID, ftime = time, y = total)], baseW, by = "ID")
Lg <- Lg[!is.na(y)]; for (v in covars) Lg <- Lg[!is.na(get(v))]
show_lmm(lmer(y ~ pheno*ftime + age + ragender + educ4f + marry_bin + region + hrural +
              rural2 + smokev + drinkl + work + retire + logcons + chronicf + adl_dis +
              (ftime|ID), data = Lg, REML = FALSE, control = lmerControl(optimizer = "bobyqa")),
         "WHO-LMM global")
svw <- merge(sv15, baseW, by = "ID")   # baseW 已含 WHO 表型 pheno
svw <- svw[!is.na(pheno)]
for (v in c("age","ragender","educ4f","marry_bin","region","hrural","rural2","smokev",
            "drinkl","work","retire","logcons","chronicf","adl_dis")) svw <- svw[!is.na(get(v))]
mwho <- run_cox(svw, "WHO-Cox M4")

cat("\n########## 2. 合并肌少组(NS+OS vs 非肌少)##########\n")
base[, sarc_any := pheno %in% c("NS","OS")]
Ls <- merge(cog2[, .(ID, ftime = time, y = total)], base, by = "ID")
Ls <- Ls[!is.na(y)]; for (v in covars) Ls <- Ls[!is.na(get(v))]
mm <- lmer(y ~ sarc_any*ftime + age + ragender + educ4f + marry_bin + region + hrural +
           rural2 + smokev + drinkl + work + retire + logcons + chronicf + adl_dis +
           (ftime|ID), data = Ls, REML = FALSE, control = lmerControl(optimizer = "bobyqa"))
cf <- as.data.frame(summary(mm)$coefficients); ci <- confint(mm, method = "Wald")
pf <- function(t) 2*pnorm(-abs(t))
cat(sprintf("[merged-LMM global] 肌少 基线 %+.3f (%+.3f,%+.3f) | 下降 %+.4f (%+.3f,%+.3f) p=%.4g\n",
    cf["sarc_anyTRUE","Estimate"], ci["sarc_anyTRUE",1], ci["sarc_anyTRUE",2],
    cf["sarc_anyTRUE:ftime","Estimate"], ci["sarc_anyTRUE:ftime",1], ci["sarc_anyTRUE:ftime",2],
    pf(cf["sarc_anyTRUE:ftime","t value"])))
svm <- merge(sv15, base, by = "ID")   # 完整协变量 + sarc_any
svm <- svm[!is.na(sarc_any)]
for (v in c("age","ragender","educ4f","marry_bin","region","hrural","rural2","smokev",
            "drinkl","work","retire","logcons","chronicf","adl_dis")) svm <- svm[!is.na(get(v))]
f2 <- paste("Surv(t, event) ~ sarc_any +", f_main0)
m <- coxph(as.formula(f2), data = svm)
cf <- summary(m)$coefficients; ci <- confint(m)
cat(sprintf("[merged-Cox M4] N=%d 事件=%d | 肌少 HR=%.3f (%.3f-%.3f) p=%.4g\n",
    m$n, m$nevent, exp(cf["sarc_anyTRUE","coef"]), exp(ci["sarc_anyTRUE",1]),
    exp(ci["sarc_anyTRUE",2]), cf["sarc_anyTRUE","Pr(>|z|)"]))

cat("\n########## 3. 反向因果三件套 ##########\n")
sv <- merge(sv15, base, by = "ID")   # 完整协变量 + 基线认知 total_cognition
for (v in c("age","ragender","educ4f","marry_bin","region","hrural","rural2","smokev",
            "drinkl","work","retire","logcons","chronicf","adl_dis","total_cognition"))
  sv <- sv[!is.na(get(v))]
## 3a landmark:排除前2年事件(风险集=2年时无事件)
svl <- copy(sv)
svl[event == 1 & t <= 2, rm := TRUE]
svl <- svl[is.na(rm)][, rm := NULL]
svl[, t := pmax(t, 2)]
run_cox(svl, "3a landmark(2年,事件N=%d内含)")
cat("  landmark 后事件数:", sum(svl$event), "\n")
## 3b 额外调整基线全局认知
run_cox(sv, "3b +基线认知", extra = "total_cognition")
## 3c 排除基线认知最低20%
q20 <- quantile(sv$total_cognition, 0.20, na.rm = TRUE)
svx <- sv[total_cognition > q20]
mc <- run_cox(svx, "3c 排除最低20%")
cat("  排除切点(20%分位)=", q20, "\n")

cat("\n########## 4. E-values(M4 HR)##########\n")
ev <- function(hr) { h <- ifelse(hr >= 1, hr, 1/hr); h + sqrt(h * (h - 1)) }
tbl <- data.table(pheno = c("NS","ONS","OS"),
  HR = c(1.263, 0.825, 1.380),
  lo = c(1.089, 0.747, 1.120), hi = c(1.465, 0.912, 1.701))
tbl[, E_point := ev(HR)]
tbl[, E_lo := fifelse(lo > 1, ev(lo), NA_real_)]
tbl[, E_hi := fifelse(hi < 1, ev(hi), NA_real_)]
cat("E-value 点估计;若HR>1给CI下限的E;若HR<1给CI上限的E:\n")
print(tbl, digits = 3)
fwrite(tbl, "evalues_m4.csv")
})
writeLines(out, "08_sas_report.txt")
cat("done\n")
