# 07b_interactions.R — 仅重跑 F 段:三阶交互系数+95%CI(修正匹配)
suppressMessages({library(data.table); library(lme4); library(survival)})
setwd("/Users/liyanjiao/Documents/ch/修稿_Frontiers/pipeline")
load("derived_corrected.RData")
out <- capture.output({

base[, pheno   := factor(pheno, levels = c("NONS","NS","ONS","OS"))]
base[, educ4f  := factor(educ4, levels = c(1,2,3,4))]
base[, marry_bin := fifelse(marry == 1, 1L, 0L)]
base[, chronicf := factor(chronic, levels = c("0","1","2+"))]
base[, agegrp3 := fcase(age < 60, "45-59", age < 70, "60-69", default = "70+")]
pfromt <- function(t) 2*pnorm(-abs(t))
covars <- c("age","ragender","educ4f","marry_bin","region","hrural","rural2",
            "smokev","drinkl","work","retire","logcons","chronicf","adl_dis")

cat("########## F. 三阶交互(表型×时间×亚组)系数+95%CI ##########\n")
res <- list()
for (yn in c("global","episodic","mental")) {
  yv <- switch(yn, global = "total", episodic = "recall", mental = "exec")
  L <- merge(cog2[, .(ID, ftime = time, y = get(yv))], base, by = "ID")
  L <- L[!is.na(y)]; for (v in covars) L <- L[!is.na(get(v))]
  subs <- list(list("sex", "ragender", TRUE),
               list("age group", "agegrp3", FALSE),
               list("residence", "hrural", TRUE))
  for (s in subs) {
    Ls <- copy(L)
    if (s[2] == "ragender") { Ls[, sg := factor(ragender, levels = c(1, 0), labels = c("men","women"))] }
    else if (s[2] == "agegrp3") { Ls[, sg := factor(agegrp3, c("45-59","60-69","70+"))] }
    else { Ls[, sg := factor(hrural, levels = c(0, 1), labels = c("urban","rural"))] }
    cv <- if (s[2] == "ragender") setdiff(covars, "ragender") else
          if (s[2] == "hrural")   setdiff(covars, "hrural") else covars
    fml <- paste("y ~ pheno*ftime*sg +", paste(cv, collapse = " + "), "+ (ftime|ID)")
    m <- lmer(fml, data = Ls, REML = FALSE, control = lmerControl(optimizer = "bobyqa"))
    cf <- as.data.frame(summary(m)$coefficients); ci <- confint(m, method = "Wald")
    tn <- grep(":ftime.*:sg", rownames(cf), value = TRUE)
    cat(sprintf("\n[%s × %s] N行=%d 人=%d\n", yn, s[1], nrow(Ls), uniqueN(Ls$ID)))
    for (nm in tn) {
      cat(sprintf("  %-28s %+.4f (%+.4f,%+.4f) p=%.4g\n",
          nm, cf[nm,"Estimate"], ci[nm,1], ci[nm,2], pfromt(cf[nm,"t value"])))
      res[[length(res)+1]] <- data.table(outcome = yn, subgroup = s[1], term = nm,
        est = cf[nm,"Estimate"], lo = ci[nm,1], hi = ci[nm,2], p = pfromt(cf[nm,"t value"]))
    }
  }
}
fwrite(rbindlist(res), "interactions_ci.csv")
})
writeLines(out, "07b_interactions_report.txt")
cat("done\n")
