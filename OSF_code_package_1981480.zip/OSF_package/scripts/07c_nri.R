# 07c_nri.R — 增量价值补充:连续 NRI + 校准度(Cox,修正结局)
suppressMessages({library(data.table); library(survival); library(nricens)})
setwd("/Users/liyanjiao/Documents/ch/修稿_Frontiers/pipeline")
load("derived_corrected.RData")
sv15 <- readRDS("sv_imp15.rds")
sv <- merge(sv15, base, by = "ID")
sv[, pheno := factor(pheno, levels = c("NONS","NS","ONS","OS"))]
sv[, educ4f := factor(educ4, levels = c(1,2,3,4))]
sv[, marry_bin := fifelse(marry == 1, 1L, 0L)]
sv[, chronicf := factor(chronic, levels = c("0","1","2+"))]
sv[, ow_cat := fifelse(bmi >= 24, 1L, 0L)]
sv[, sarc_cat := fifelse((ragender == 1 & grip < 28) | (ragender == 0 & grip < 18), 1L, 0L)]
## 先做完全病例筛选,保证 predict 长度一致
needvars <- c("t","event","bmi","grip","age","ragender","educ4f","marry_bin","region",
              "hrural","rural2","smokev","drinkl","work","retire","logcons","chronicf","adl_dis")
for (v in needvars) sv <- sv[!is.na(get(v))]
sv[, ow_cat := fifelse(bmi >= 24, 1L, 0L)]
sv[, sarc_cat := fifelse((ragender == 1 & grip < 28) | (ragender == 0 & grip < 18), 1L, 0L)]
f_main <- "age + ragender + educ4f + marry_bin + region + hrural + rural2 + smokev + drinkl + work + retire + logcons + chronicf + adl_dis"
m_bmi  <- coxph(as.formula(paste("Surv(t, event) ~ ow_cat +", f_main)), data = sv, x = TRUE)
m_both <- coxph(as.formula(paste("Surv(t, event) ~ ow_cat + sarc_cat +", f_main)), data = sv, x = TRUE)
cat(sprintf("完全病例 N=%d 事件=%d\n", nrow(sv), sum(sv$event)))

out <- capture.output({
  set.seed(20261)
  ## 用两模型的 5 年预测风险做连续 NRI(避免新版 mdl 接口的兼容问题)
  lp0 <- predict(m_bmi,  type = "lp"); lp1 <- predict(m_both, type = "lp")
  bh  <- basehaz(m_bmi, centered = FALSE)
  h5  <- approx(bh$time, bh$hazard, xout = 5, method = "constant")$y
  p0  <- 1 - exp(-exp(lp0) * h5)
  p1  <- 1 - exp(-exp(lp1) * h5)
  nri <- nricens(time = sv$t, event = sv$event,
                 p.std = p0, p.new = p1,
                 t0 = 5, updown = "diff", cut = 0,
                 niter = 1000, msg = FALSE)
  cat("== NRI(5 年;基准 = BMI 分类 + 协变量;新增 = 连续 BMI + 握力)==\n")
  print(nri)

  ## 校准度:模型(BMI类+握力)的 5 年预测风险 vs KM 观测风险(五分位)
  lp <- predict(m_both, type = "lp")
  bh <- basehaz(m_both, centered = FALSE)
  h5 <- approx(bh$time, bh$hazard, xout = 5, method = "constant")$y
  sv[, p5 := 1 - exp(-exp(lp) * h5)]
  sv[, quint := cut(p5, quantile(p5, 0:5/5), include.lowest = TRUE, labels = 1:5)]
  cat("\n== 校准度(5 年,按预测风险五分位)==\n")
  cal <- sv[, .(
    n = .N,
    mean_pred = mean(p5),
    obs5 = { sf <- survfit(Surv(t, event) ~ 1, data = .SD);
             1 - summary(sf, times = 5)$surv },
    events5 = sum(event == 1 & t <= 5)),
    by = quint][order(quint)]
  print(cal, digits = 3)
  cat(sprintf("\n总体: mean_pred=%.3f vs obs5=%.3f\n",
      sv[, mean(p5)],
      1 - summary(survfit(Surv(t, event) ~ 1, data = sv), times = 5)$surv))
  fwrite(cal, "calibration_quintiles.csv")
})
writeLines(out, "07c_nri_report.txt")
cat("done\n")
