# =============================================================
# 06_figures.R — 三张出版级图(英文,300dpi)
# Fig1 流程图 | Fig2 轨迹图(双面板) | Fig3 CIF 曲线
# =============================================================
suppressMessages({library(data.table); library(lme4); library(ggplot2)})
setwd("/Users/liyanjiao/Documents/ch/修稿_Frontiers/pipeline")
load("derived_corrected.RData")

base[, pheno   := factor(pheno, levels = c("NONS","NS","ONS","OS"))]
base[, educ4f  := factor(educ4, levels = c(1,2,3,4))]
base[, marry_bin := fifelse(marry == 1, 1L, 0L)]
base[, chronicf := factor(chronic, levels = c("0","1","2+"))]
covars <- c("age","ragender","educ4f","marry_bin","region","hrural","rural2",
            "smokev","drinkl","work","retire","logcons","chronicf","adl_dis")
cols <- c(NONS = "grey40", NS = "#D55E00", ONS = "#0072B2", OS = "#CC79A7")
ngrp <- base[, .N, by = pheno]

## ============ Fig 2:预测认知轨迹(边际标准化 g-computation) ============
mk_L <- function(yvar) {
  L <- merge(cog2[, .(ID, ftime = time, y = get(yvar))], base, by = "ID")
  L <- L[!is.na(y)]
  for (v in covars) L <- L[!is.na(get(v))]
  L
}
marg_traj <- function(m, L, ylabel, outfile) {
  trm <- delete.response(terms(m)); b <- fixef(m); V <- vcov(m)
  res <- rbindlist(lapply(levels(L$pheno), function(p) rbindlist(lapply(c(0,2,4,7), function(t) {
    Lp <- copy(L); Lp[, pheno := p]; Lp[, ftime := t]
    Xp <- model.matrix(trm, data = Lp)
    xb <- colMeans(Xp)
    est <- sum(xb * b); se <- sqrt(as.numeric(t(xb) %*% V %*% xb))
    data.table(pheno = p, time = t, est = est, lo = est - 1.96*se, hi = est + 1.96*se)
  }))))
  res[, pheno := factor(pheno, levels = c("NONS","NS","ONS","OS"))]
  g <- ggplot(res, aes(time, est, color = pheno, fill = pheno)) +
    geom_ribbon(aes(ymin = lo, ymax = hi), alpha = .12, color = NA) +
    geom_line(linewidth = .9) +
    scale_color_manual(values = cols, name = NULL,
      labels = paste0(levels(res$pheno), " (n=", ngrp$N[match(levels(res$pheno), ngrp$pheno)], ")")) +
    scale_fill_manual(values = cols, guide = "none") +
    scale_x_continuous(breaks = c(0,2,4,7)) +
    labs(x = "Years since baseline (2011)", y = ylabel) +
    theme_classic(base_size = 13) +
    theme(legend.position = "bottom",
          legend.background = element_rect(fill = alpha("white", .8), color = NA))
  ggsave(outfile, g, width = 6.6, height = 4.6, dpi = 300)
  cat("已保存:", outfile, "\n")
  print(res[, .(pheno, time, round(est,2), round(lo,2), round(hi,2))])
}

m_glob <- readRDS("fit_lmm_global_educ4.rds")
marg_traj(m_glob, mk_L("total"), "Global cognition (0–21)", "fig2a_trajectory_global.png")

if (!file.exists("fit_lmm_episodic_educ4.rds")) {
  L <- mk_L("recall")
  m <- lmer(y ~ pheno * ftime + age + ragender + educ4f + marry_bin + region + hrural +
            rural2 + smokev + drinkl + work + retire + logcons + chronicf + adl_dis +
            (ftime | ID), data = L, REML = FALSE, control = lmerControl(optimizer = "bobyqa"))
  saveRDS(m, "fit_lmm_episodic_educ4.rds")
}
m_epi <- readRDS("fit_lmm_episodic_educ4.rds")
marg_traj(m_epi, mk_L("recall"), "Episodic memory (0–10)", "fig2b_trajectory_episodic.png")

## ============ Fig 3:CIF 曲线 ============
load("cif_curves.RData")
cif_dt <- rbindlist(lapply(names(cif_out), function(nm) {
  if (!grepl(" 1$", nm)) return(NULL)
  o <- cif_out[[nm]]
  data.table(pheno = sub(" 1$", "", nm), time = o$time, cif = o$est)
}))
cif_dt[, pheno := factor(pheno, levels = c("NONS","NS","ONS","OS"))]
g3 <- ggplot(cif_dt, aes(time, 100*cif, color = pheno)) +
  geom_step(linewidth = .85) +
  scale_color_manual(values = cols, name = NULL,
    labels = paste0(levels(cif_dt$pheno), " (n=", ngrp$N[match(levels(cif_dt$pheno), ngrp$pheno)], ")")) +
  labs(x = "Years since baseline", y = "Cumulative incidence of cognitive impairment (%)") +
  coord_cartesian(ylim = c(0, 45)) +
  theme_classic(base_size = 13) +
  theme(legend.position = "bottom",
        legend.background = element_rect(fill = alpha("white", .8), color = NA))
ggsave("fig3_cif.png", g3, width = 6.2, height = 4.6, dpi = 300)
cat("已保存: fig3_cif.png\n")

## ============ Fig 1:流程图 ============
dt <- fread("/Users/liyanjiao/Documents/ch/charls.csv")
setnames(dt, sub(" [(].*[)]$", "", names(dt)))
dt[, ID := as.character(ID)]
w1 <- dt[wave == 1]
cog_any <- dt[wave <= 4 & !is.na(total_cognition), unique(ID)]
s0 <- w1[age >= 45];                                        n1 <- nrow(s0); e1 <- nrow(w1) - n1
s1 <- s0[(is.na(memrye)|memrye==0) & (is.na(psyche)|psyche==0) & (is.na(stroke)|stroke==0)]; e2 <- n1 - nrow(s1)
s2 <- s1[!is.na(bmi) & bmi>=10 & bmi<=60];                  e3 <- nrow(s1) - nrow(s2)
s3 <- s2[!is.na(gripsum) & gripsum>=0 & gripsum<=80];       e4 <- nrow(s2) - nrow(s3)
s4 <- s3[ID %in% cog_any];                                  e5 <- nrow(s3) - nrow(s4)

boxes <- data.frame(
  y    = 5:1,
  lab  = c(sprintf("CHARLS Wave 1 (2011) participants\nn = %d", nrow(w1)),
           sprintf("Aged ≥ 45 years\nn = %d", n1),
           sprintf("No memory disease, psychiatric disorders,\nor stroke at baseline\nn = %d", nrow(s1)),
           sprintf("Valid BMI (10–60 kg/m²) and handgrip\nstrength (0–80 kg)\nn = %d", nrow(s3)),
           sprintf("Analytic sample\nn = %d", nrow(s4))))
excl <- data.frame(
  y    = 4:1,
  lab  = c(sprintf("Excluded: age < 45\n(n = %d)", e1),
           sprintf("Excluded: memory disease /\npsychiatric disorders / stroke\n(n = %d)", e2),
           sprintf("Excluded: missing or implausible BMI\n(n = %d)", e3),
           sprintf("Excluded: missing grip or no cognitive\nassessment 2011–2018 (n = %d)", e4 + e5)))
arr <- data.frame(y = 5:2, yend = 4:1)
con <- data.frame(y = 4:1)

g1 <- ggplot() +
  geom_rect(data = boxes, aes(xmin = 1.2, xmax = 6.2, ymin = y - .40, ymax = y + .40),
            fill = "grey96", color = "black", linewidth = .4) +
  geom_text(data = boxes, aes(x = 3.7, y = y, label = lab), size = 3.35, lineheight = .95) +
  geom_segment(data = arr, aes(x = 3.7, xend = 3.7, y = y - .40, yend = yend + .40),
               arrow = arrow(length = unit(.10, "in")), linewidth = .4) +
  geom_rect(data = excl, aes(xmin = 7.6, xmax = 11.0, ymin = y - .33, ymax = y + .33),
            fill = NA, color = "grey45", linetype = 2, linewidth = .35) +
  geom_text(data = excl, aes(x = 9.3, y = y, label = lab), size = 3.0, lineheight = .95) +
  geom_segment(data = con, aes(x = 6.2, xend = 7.6, y = y, yend = y),
               color = "grey45", linewidth = .3) +
  xlim(0.6, 11.4) + ylim(0.4, 5.6) +
  theme_void()
ggsave("fig1_flow.png", g1, width = 8.0, height = 6.0, dpi = 300)
cat(sprintf("已保存: fig1_flow.png  (最终N=%d)\n", nrow(s4)))
cat("== 06 完成 ==\n")
