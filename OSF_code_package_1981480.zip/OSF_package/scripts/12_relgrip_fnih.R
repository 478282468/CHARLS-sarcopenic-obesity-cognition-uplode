# 12_relgrip_fnih.R — 修正版 FNIH 相对握力分析(官方切点 grip/BMI <1.00 M / <0.56 F)
suppressMessages({library(data.table); library(survival)})
setwd("/Users/liyanjiao/Documents/ch/修稿_Frontiers/pipeline")
load("derived_corrected.RData")
sv15 <- readRDS("sv_imp15.rds")
base[, educ4f := factor(educ4, levels=c(1,2,3,4))]
base[, marry_bin := fifelse(marry==1,1L,0L)]
base[, chronicf := factor(chronic, levels=c("0","1","2+"))]
base[, sarc_rel := fifelse((ragender==1 & grip/bmi < 1.00) | (ragender==0 & grip/bmi < 0.56), 1L, 0L)]
base[, ow_rel := fifelse(bmi >= 24, 1L, 0L)]
base[, pheno_rel := fcase(ow_rel==0 & sarc_rel==0, "NONS", ow_rel==0 & sarc_rel==1, "NS",
                          ow_rel==1 & sarc_rel==0, "ONS", default = "OS")]
base[, pheno_rel := factor(pheno_rel, levels = c("NONS","NS","ONS","OS"))]
print(base[, .N, by = pheno_rel][order(pheno_rel)])
cat(sprintf("与绝对切点表型一致率: %.1f%%\n", 100*mean(base$pheno == base$pheno_rel)))
sv <- merge(sv15, base, by = "ID")
for (v in c("age","ragender","educ4f","marry_bin","region","hrural","rural2","smokev",
            "drinkl","work","retire","logcons","chronicf","adl_dis")) sv <- sv[!is.na(get(v))]
m <- coxph(Surv(t, event) ~ pheno_rel + age + ragender + educ4f + marry_bin + region + hrural +
           rural2 + smokev + drinkl + work + retire + logcons + chronicf + adl_dis, data = sv)
cf <- as.data.frame(summary(m)$coefficients); ci <- confint(m)
cat(sprintf("Cox M4 (N=%d, 事件=%d):\n", m$n, m$nevent))
for (p in c("NS","ONS","OS")) {
  nm <- paste0("pheno_rel", p)
  cat(sprintf("  %-4s HR=%.3f (%.3f-%.3f) p=%.4g\n", p,
      exp(cf[nm,"coef"]), exp(ci[nm,1]), exp(ci[nm,2]), cf[nm,"Pr(>|z|)"]))
}
