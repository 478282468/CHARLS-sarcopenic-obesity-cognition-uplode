# =============================================================
# 11_fig_fixes.R — 图件修复(fig1 拆步 / fig3 修复 + Gray 检验 / eFig2 森林图)
# =============================================================
suppressMessages({library(data.table); library(ggplot2); library(survival); library(cmprsk)})
setwd("/Users/liyanjiao/Documents/ch/修稿_Frontiers/pipeline")
load("derived_corrected.RData")
sv15 <- readRDS("sv_imp15.rds")
base[, pheno := factor(pheno, levels = c("NONS","NS","ONS","OS"))]
cols <- c(NONS = "grey40", NS = "#D55E00", ONS = "#0072B2", OS = "#CC79A7")
ngrp <- base[, .N, by = pheno]

## ============ Fig 1:流程图(拆分 BMI / 握力 两步) ============
dt <- fread("/Users/liyanjiao/Documents/ch/charls.csv")
setnames(dt, sub(" [(].*[)]$", "", names(dt)))
dt[, ID := as.character(ID)]
w1 <- dt[wave == 1]
cog_any <- dt[wave <= 4 & !is.na(total_cognition), unique(ID)]
s0 <- w1[age >= 45];                                        n1 <- nrow(s0); e1 <- nrow(w1) - n1
s1 <- s0[(is.na(memrye)|memrye==0) & (is.na(psyche)|psyche==0) & (is.na(stroke)|stroke==0)]; e2 <- n1 - nrow(s1)
s2 <- s1[!is.na(bmi) & bmi>=10 & bmi<=60];                  e3 <- nrow(s1) - nrow(s2)
s3 <- s2[!is.na(gripsum) & gripsum>=0 & gripsum<=80];       e4 <- nrow(s2) - nrow(s3)
s4 <- s3[ID %in% cog_any];                                  e5 <- nrow(s3) - nrow(s4)

boxes <- data.frame(
  y   = 6:1,
  lab = c(sprintf("CHARLS Wave 1 (2011) participants\nn = %d", nrow(w1)),
          sprintf("Aged \u2265 45 years\nn = %d", n1),
          sprintf("No memory disease, psychiatric disorders,\nor stroke at baseline\nn = %d", nrow(s1)),
          sprintf("Valid BMI (10\u201360 kg/m\u00b2)\nn = %d", nrow(s2)),
          sprintf("Valid handgrip strength (0\u201380 kg)\nn = %d", nrow(s3)),
          sprintf("\u2265 1 cognitive assessment 2011\u20132018\nAnalytic sample  n = %d", nrow(s4))))
excl <- data.frame(
  y   = 5:1,
  lab = c(sprintf("Excluded: age < 45\n(n = %d)", e1),
          sprintf("Excluded: memory disease /\npsychiatric disorders / stroke\n(n = %d)", e2),
          sprintf("Excluded: missing or\nimplausible BMI (n = %d)", e3),
          sprintf("Excluded: missing or\nimplausible handgrip (n = %d)", e4),
          sprintf("Excluded: no cognitive\nassessment (n = %d)", e5)))
arr <- data.frame(y = 6:2, yend = 5:1)
con <- data.frame(y = 5:1)

g1 <- ggplot() +
  geom_rect(data = boxes, aes(xmin = 1.2, xmax = 6.2, ymin = y - .40, ymax = y + .40),
            fill = "grey96", color = "black", linewidth = .4) +
  geom_text(data = boxes, aes(x = 3.7, y = y, label = lab), size = 3.3, lineheight = .95) +
  geom_segment(data = arr, aes(x = 3.7, xend = 3.7, y = y - .40, yend = yend + .40),
               arrow = arrow(length = unit(.10, "in")), linewidth = .4) +
  geom_rect(data = excl, aes(xmin = 7.6, xmax = 11.2, ymin = y - .33, ymax = y + .33),
            fill = NA, color = "grey45", linetype = 2, linewidth = .35) +
  geom_text(data = excl, aes(x = 9.4, y = y, label = lab), size = 3.0, lineheight = .95) +
  geom_segment(data = con, aes(x = 6.2, xend = 7.6, y = y, yend = y),
               color = "grey45", linewidth = .3) +
  xlim(0.6, 11.6) + ylim(0.4, 6.6) +
  theme_void()
ggsave("fig1_flow.png", g1, width = 8.2, height = 6.6, dpi = 300)
cat(sprintf("fig1_flow.png 已保存 (最终N=%d)\n", nrow(s4)))

## ============ Fig 3:CIF(风险集 n + Gray 检验 + 轴修复) ============
sv <- merge(sv15, base[, .(ID, pheno)], by = "ID")
# 竞争风险编码:1=障碍, 2=死亡(无障碍), 0=删失
sv <- merge(sv, dinfo[td > 0, .(ID, td)], by = "ID", all.x = TRUE)
sv[event == 0 & !is.na(td) & td < t, `:=`(t = td, ev2 = 2L)]
sv[is.na(ev2), ev2 := event]
sv[, ev2 := fifelse(event == 1, 1L, ev2)]
risk_n <- sv[, .N, by = pheno][order(pheno)]
ci_fit <- cuminc(sv$t, sv$ev2, group = as.character(sv$pheno), cencode = 0)
gt <- ci_fit$Tests["1", "pv"]   # Gray 多组检验 P 值(cause 1 = 障碍)
cat("Gray test P =", format.pval(gt, eps = 0.001), "\n")
gp <- if (gt < 0.001) "Gray's test P < .001" else sprintf("Gray's test P = %.3f", gt)

load("cif_curves.RData")
cif_dt <- rbindlist(lapply(names(cif_out), function(nm) {
  if (!grepl(" 1$", nm)) return(NULL)
  o <- cif_out[[nm]]
  data.table(pheno = sub(" 1$", "", nm), time = o$time, cif = o$est)
}))
cif_dt[, pheno := factor(pheno, levels = c("NONS","NS","ONS","OS"))]
g3 <- ggplot(cif_dt, aes(time, 100 * cif, color = pheno)) +
  geom_step(linewidth = .85) +
  scale_color_manual(values = cols, name = NULL,
    labels = paste0(levels(cif_dt$pheno), " (n = ",
                    risk_n$N[match(levels(cif_dt$pheno), risk_n$pheno)], ")")) +
  labs(x = "Years since baseline",
       y = "Cumulative incidence of\ncognitive impairment (%)",
       subtitle = gp) +
  coord_cartesian(ylim = c(0, 45)) +
  theme_classic(base_size = 12) +
  theme(legend.position = "bottom",
        legend.background = element_rect(fill = alpha("white", .8), color = NA),
        plot.title = element_text(size = 11),
        plot.margin = margin(12, 12, 6, 10))
ggsave("fig3_cif.png", g3, width = 6.8, height = 5.2, dpi = 300)
cat("fig3_cif.png 已保存\n")

## ============ eFigure 2:敏感性分析森林图 ============
sens <- data.table(
  analysis = rep(c("Main Cox (Model 4)","Two consecutive waves","\u22121.0 SD norms","WHO cutoff (\u226525)",
                   "Interval-censored","Age as time scale","Fine\u2013Gray","FNIH relative strength",
                   "+ CES-D-10","IPW","PA subgroup","Landmark 2 y","+ Baseline cognition",
                   "Exclude lowest quintile","Time-varying phenotype"), each = 3),
  pheno = rep(c("LG-NW","NG-OW","LG-OW"), 15),
  hr = c(1.263,0.825,1.380, 1.299,0.854,1.239, 1.323,0.896,1.225, 1.311,0.864,1.411,
         1.265,0.825,1.385, 1.240,0.823,1.389, 1.193,0.821,1.333, 1.245,0.820,1.251,
         1.231,0.845,1.373, 1.211,0.848,1.377, 1.287,0.821,1.356, 1.114,0.862,1.498,
         1.072,0.870,1.269, 1.223,0.844,1.483, 1.263,0.858,1.209),
  lo = c(1.089,0.747,1.120, 1.108,0.765,0.980, 1.151,0.821,0.995, 1.138,0.777,1.118,
         1.083,0.743,1.139, 1.068,0.745,1.127, 1.028,0.745,1.080, 1.005,0.743,1.005,
         1.060,0.764,1.114, 1.022,0.765,1.093, 1.019,0.705,0.972, 0.903,0.761,1.143,
         0.914,0.785,1.018, 0.968,0.738,1.074, 1.087,0.775,0.969),
  hi = c(1.465,0.912,1.701, 1.523,0.953,1.565, 1.520,0.978,1.508, 1.510,0.961,1.782,
         1.477,0.916,1.684, 1.440,0.909,1.712, 1.384,0.905,1.645, 1.541,0.904,1.557,
         1.430,0.934,1.692, 1.436,0.941,1.736, 1.624,0.956,1.890, 1.375,0.977,1.962,
         1.258,0.964,1.582, 1.544,0.964,2.048, 1.469,0.951,1.508))
sens[, pheno := factor(pheno, levels = c("LG-NW","NG-OW","LG-OW"))]
sens[, analysis := factor(analysis, levels = rev(unique(analysis)))]
ge <- ggplot(sens, aes(hr, analysis, color = pheno)) +
  geom_vline(xintercept = 1, linetype = 2, color = "grey55") +
  geom_pointrange(aes(xmin = lo, xmax = hi),
                  position = position_dodge(width = .55), size = .32, linewidth = .55) +
  scale_color_manual(values = c("LG-NW" = "#D55E00", "NG-OW" = "#0072B2", "LG-OW" = "#CC79A7"), name = NULL) +
  scale_x_log10(breaks = c(.75, 1, 1.25, 1.5, 2)) +
  labs(x = "Hazard ratio (95% CI, log scale)", y = NULL,
       title = "Sensitivity analyses: incident screen-defined cognitive impairment (reference: NG-NW)") +
  theme_classic(base_size = 11.5) +
  theme(legend.position = "top",
        plot.title = element_text(size = 11.5),
        panel.grid.major.y = element_line(color = "grey93", linewidth = .3))
ggsave("efig2_forest.png", ge, width = 8.2, height = 7.6, dpi = 300)
cat("efig2_forest.png 已保存\n")
cat("== 11 完成 ==\n")
