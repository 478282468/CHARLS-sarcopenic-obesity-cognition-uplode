# 10_tables_export.R — 导出补充材料所需表格数据
suppressMessages({library(data.table); library(lme4); library(survival)})
setwd("/Users/liyanjiao/Documents/ch/修稿_Frontiers/pipeline")
load("derived_corrected.RData")
sv15 <- readRDS("sv_imp15.rds")
base[, pheno := factor(pheno, levels = c("NONS","NS","ONS","OS"))]
base[, educ4f := factor(educ4, levels = c(1,2,3,4))]
base[, marry_bin := fifelse(marry == 1, 1L, 0L)]
base[, chronicf := factor(chronic, levels = c("0","1","2+"))]

sv <- merge(sv15, base, by = "ID")
for (v in c("age","ragender","educ4f","marry_bin","region","hrural","rural2","smokev",
            "drinkl","work","retire","logcons","chronicf","adl_dis")) sv <- sv[!is.na(get(v))]

out <- capture.output({
  cat("== Cox Models 1-4 ==\n")
  m1 <- coxph(Surv(t, event) ~ pheno, data = sv)
  m2 <- coxph(Surv(t, event) ~ pheno + age + ragender + educ4f + marry_bin + region + hrural + smokev + drinkl, data = sv)
  m3 <- coxph(Surv(t, event) ~ pheno + age + ragender + educ4f + marry_bin + region + hrural + rural2 + smokev + drinkl + work + retire + logcons, data = sv)
  m4 <- coxph(Surv(t, event) ~ pheno + age + ragender + educ4f + marry_bin + region + hrural + rural2 + smokev + drinkl + work + retire + logcons + chronicf + adl_dis, data = sv)
  for (nm in c("m1","m2","m3","m4")) {
    m <- get(nm); cf <- summary(m)$coefficients; ci <- confint(m)
    cat(sprintf("\n[%s] N=%d 事件=%d\n", nm, m$n, m$nevent))
    for (p in c("NS","ONS","OS")) {
      nmp <- paste0("pheno", p)
      cat(sprintf("  %-4s HR=%.3f (%.3f-%.3f) p=%.4g\n", p,
          exp(cf[nmp,"coef"]), exp(ci[nmp,1]), exp(ci[nmp,2]), cf[nmp,"Pr(>|z|)"]))
    }
  }
  fwrite(rbindlist(lapply(c("m1","m2","m3","m4"), function(nm) {
    m <- get(nm); cf <- summary(m)$coefficients; ci <- confint(m)
    data.table(model = nm, variable = rownames(cf), HR = exp(cf[,"coef"]),
               lo = exp(ci[,1]), hi = exp(ci[,2]), p = cf[,"Pr(>|z|)"])
  })), "cox_m1_m4_full.csv")

  cat("\n== 随机斜率 AIC 对比 ==\n")
  covars <- c("age","ragender","educ4f","marry_bin","region","hrural","rural2",
              "smokev","drinkl","work","retire","logcons","chronicf","adl_dis")
  for (yn in c("global","episodic","mental")) {
    yv <- switch(yn, global = "total", episodic = "recall", mental = "exec")
    L <- merge(cog2[, .(ID, ftime = time, y = get(yv))], base, by = "ID")
    L <- L[!is.na(y)]; for (v in covars) L <- L[!is.na(get(v))]
    cv <- paste(covars, collapse = " + ")
    m_ri <- lmer(as.formula(paste("y ~ pheno*ftime +", cv, "+ (1|ID)")), data = L, REML = FALSE, control = lmerControl(optimizer = "bobyqa"))
    m_rs <- lmer(as.formula(paste("y ~ pheno*ftime +", cv, "+ (ftime|ID)")), data = L, REML = FALSE, control = lmerControl(optimizer = "bobyqa"))
    a1 <- AIC(m_ri); a2 <- AIC(m_rs); b1 <- BIC(m_ri); b2 <- BIC(m_rs)
    cat(sprintf("[%s] RI: AIC=%.0f BIC=%.0f | RS: AIC=%.0f BIC=%.0f | dAIC=%.0f dBIC=%.0f\n",
        yn, a1, b1, a2, b2, a1 - a2, b1 - b2))
  }

  cat("\n== LMM global 完整固定效应 ==\n")
  m <- readRDS("fit_lmm_global_educ4.rds")
  cf <- as.data.frame(summary(m)$coefficients); ci <- confint(m, method = "Wald")
  lmmfe <- data.table(variable = rownames(cf), est = cf$Estimate,
                      lo = ci[rownames(cf),1], hi = ci[rownames(cf),2])
  print(lmmfe, digits = 3)
  fwrite(lmmfe, "lmm_global_fixed_effects.csv")
})
writeLines(out, "10_tables_report.txt")
cat("done\n")
