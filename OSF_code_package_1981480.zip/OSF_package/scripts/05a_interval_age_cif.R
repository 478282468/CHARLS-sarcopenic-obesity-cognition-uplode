# =============================================================
# 05a_interval_age_cif.R — Major 5 三项修正
# (a) 区间删失 Cox(icenReg,不用中点法)
# (b) 年龄作为时间尺度
# (c) 死亡竞争风险:CIF + Fine-Gray(替代 KM)
# =============================================================
suppressMessages({library(data.table); library(survival); library(icenReg); library(cmprsk)})
setwd("/Users/liyanjiao/Documents/ch/修稿_Frontiers/pipeline")
load("derived_corrected.RData")

base[, pheno := factor(pheno, levels = c("NONS","NS","ONS","OS"))]
base[, educ4f := factor(educ4, levels = c(1,2,3,4))]
base[, marry_bin := fifelse(marry == 1, 1L, 0L)]
base[, chronicf := factor(chronic, levels = c("0","1","2+"))]

sv <- readRDS("sv_imp15.rds")            # 修正结局(−1.5SD)风险集
sv <- merge(sv, base, by = "ID", all.x = TRUE)

## ---------- (a) 区间删失 Cox ----------
# 重新构造区间:左=最后正常波,右=首次障碍波(真实波次边界,非中点)
cog2 <- copy(cog)
cog2 <- merge(cog2, base[, .(ID)], by = "ID")
mk_int <- function() {
  out <- list()
  for (id in sv$ID) {
    w <- cog2[ID == id & !is.na(total), .(wave, time, total)]
    cut <- sv[ID == id, cut15] # 需要从base再取
  }
}
sv <- merge(sv, base[, .(ID, cut15)], by = "ID", all.x = TRUE, suffixes = c("",".b"))
rows <- list()
for (id in sv$ID) {
  w <- cog2[ID == id, .(wave, time, total)][!is.na(total)]
  cv <- sv[ID == id, cut15]
  ev <- w[wave >= 2 & total < cv]
  if (nrow(ev) > 0) {                    # 事件:区间=(前一波, 首障碍波]
    ew <- min(ev$time)
    lw <- max(w[time < ew, time], 0)
    rows[[length(rows)+1]] <- data.table(ID = id, l = lw, u = ew, ev = 1L)
  } else {
    lt <- if (nrow(w)) max(w$time) else 0
    rows[[length(rows)+1]] <- data.table(ID = id, l = lt, u = lt, ev = 0L)
  }
}
intdt <- rbindlist(rows)
cat(sprintf("区间删失数据: N=%d 事件=%d\n", nrow(intdt), sum(intdt$ev)))
intdt <- merge(intdt, sv, by = "ID")

mcov <- c("pheno","age","ragender","educ4f","marry_bin","region","hrural","rural2",
          "smokev","drinkl","work","retire","logcons","chronicf","adl_dis")
intdt <- intdt[complete.cases(intdt[, ..mcov])]
cat(sprintf("完全病例: N=%d 事件=%d\n", nrow(intdt), sum(intdt$ev)))
intdt[ev == 0, u := Inf]   # icenReg 约定:删失=区间(l,Inf)

fit_ic <- ic_sp(Surv(l, u, type = "interval2") ~ pheno + age + ragender + educ4f + marry_bin +
                region + hrural + rural2 + smokev + drinkl + work + retire +
                logcons + chronicf + adl_dis, data = intdt, model = "ph")
cat("\n== (a) 区间删失 Cox(icenReg, M4 协变量)==\n")
print(summary(fit_ic))

## ---------- (b) 年龄作时间尺度 ----------
svcc <- sv[complete.cases(sv[, ..mcov])]
svcc[, age_exit := age + t]
fit_age <- coxph(Surv(age, age_exit, event) ~ pheno + ragender + educ4f +
                 marry_bin + region + hrural + rural2 + smokev + drinkl +
                 work + retire + logcons + chronicf + adl_dis, data = svcc)
cf <- summary(fit_age)$coefficients; ci <- confint(fit_age)
cat("\n== (b) 年龄作时间尺度(M4)==\n")
for (p in c("NS","ONS","OS")) {
  nm <- paste0("pheno", p)
  cat(sprintf("  %-4s HR=%.3f (%.3f-%.3f) p=%.3f\n", p,
      exp(cf[nm,1]), exp(ci[nm,1]), exp(ci[nm,2]), cf[nm,5]))
}

## ---------- (c) 竞争风险:CIF + Fine-Gray ----------
# 死亡时间(相对2011年中):dyear + (dmonth-0.5)/12 - 2011.5
dinfo[, td := dyear + (dmonth - 0.5)/12 - 2011.5]
sv <- merge(sv, dinfo[, .(ID, td)], by = "ID", all.x = TRUE)
sv[, `:=`(cs = 0L, ct = t)]
sv[!is.na(td) & event == 0, `:=`(cs = 2L, ct = fifelse(td < t, pmax(td, 0.01), t))]
sv[event == 1, cs := 1L]
sv[, csf := factor(cs, levels = c(0,1,2), labels = c("censor","impair","death"))]
sv <- sv[complete.cases(sv[, ..mcov])]

cat(sprintf("\n竞争风险数据:障碍 %d | 死亡(无障碍) %d | 删失 %d\n",
    sum(sv$cs == 1), sum(sv$cs == 2), sum(sv$cs == 0)))

# Fine-Gray
fgdt <- finegray(Surv(ct, csf) ~ ., data = sv[, .(ct, csf, pheno, age, ragender,
             educ4f, marry_bin, region, hrural, rural2, smokev, drinkl,
             work, retire, logcons, chronicf, adl_dis)], etype = "impair")
fit_fg <- coxph(Surv(fgstart, fgstop, fgstatus) ~ pheno + age + ragender +
                educ4f + marry_bin + region + hrural + rural2 + smokev +
                drinkl + work + retire + logcons + chronicf + adl_dis,
                data = fgdt, weights = fgwt)
cf <- summary(fit_fg)$coefficients; ci <- confint(fit_fg)
cat("== (c) Fine-Gray 子分布风险比(M4)==\n")
for (p in c("NS","ONS","OS")) {
  nm <- paste0("pheno", p)
  cat(sprintf("  %-4s SHR=%.3f (%.3f-%.3f) p=%.3f\n", p,
      exp(cf[nm,1]), exp(ci[nm,1]), exp(ci[nm,2]), cf[nm,5]))
}

# CIF 曲线数据(存给绘图脚本)
cif_out <- cuminc(sv$ct, sv$cs, group = sv$pheno, cencode = 0)
save(cif_out, file = "cif_curves.RData")
cat("\nCIF 数据已存 cif_curves.RData(06 绘图用)\n")
cat("== 05a 完成 ==\n")
