# =============================================================
# 05c_ipw_missing_flow.R — Major 6/7/8 收尾
# (1) IPW 失访逆概率加权(Cox + LMM)
# (2) 缺失模式表(每变量缺失 n/%)
# (3) 样本流程表(初始N → 各模型N)
# (4) 体力活动亚组(phy_actb 可测者中调整 PA)
# =============================================================
suppressMessages({library(data.table); library(survival); library(lme4)})
setwd("/Users/liyanjiao/Documents/ch/修稿_Frontiers/pipeline")
load("derived_corrected.RData")

base[, pheno   := factor(pheno, levels = c("NONS","NS","ONS","OS"))]
base[, educ4f  := factor(educ4, levels = c(1,2,3,4))]
base[, marry_bin := fifelse(marry == 1, 1L, 0L)]
base[, chronicf := factor(chronic, levels = c("0","1","2+"))]
mcov <- c("pheno","age","ragender","educ4f","marry_bin","region","hrural","rural2",
          "smokev","drinkl","work","retire","logcons","chronicf","adl_dis")

sv <- readRDS("sv_imp15.rds"); sv <- merge(sv, base, by = "ID", all.x = TRUE)

## ---------- (1) IPW ----------
dinfo[, td := dyear + (dmonth - 0.5)/12 - 2011.5]
sv <- merge(sv, dinfo[, .(ID, td)], by = "ID", all.x = TRUE)
# 观测到 w4 = 有 w4 认知;w4 前死亡者不进失访模型(死亡由竞争风险处理)
sv[, obs4 := fifelse(!is.na(cog2[ID %in% ID & wave == 4, total][match(ID, cog2[wave==4]$ID)]), 1L, 0L)]
# 上面写法复杂,直接用 cog2:
w4ids <- cog2[wave == 4, unique(ID)]
sv[, obs4 := fifelse(ID %in% w4ids, 1L, 0L)]
sv[, died_pre4 := fifelse(!is.na(td) & td < 6.5, 1L, 0L)]
att <- sv[died_pre4 == 0 & complete.cases(sv[, ..mcov]) & !is.na(total_cognition)]
cat(sprintf("失访模型样本:%d | w4观测 %d (%.1f%%)\n",
    nrow(att), sum(att$obs4), 100*mean(att$obs4)))

glm_att <- glm(obs4 ~ pheno + age + ragender + educ4f + marry_bin + region +
               hrural + rural2 + smokev + drinkl + work + retire + logcons +
               chronicf + adl_dis + total_cognition, family = binomial, data = att)
att[, pobs := predict(glm_att, type = "response")]
att[, sw := (mean(obs4)) / pobs]                # 稳定化权重(观测者)
att[, sw := pmin(pmax(sw, 0.2), 5)]             # 截尾 [0.2, 5]
cat(sprintf("稳定化权重:mean=%.3f, SD=%.3f\n\n", mean(att$sw), sd(att$sw)))

m_ipw <- coxph(Surv(t, event) ~ pheno + age + ragender + educ4f + marry_bin +
               region + hrural + rural2 + smokev + drinkl + work + retire +
               logcons + chronicf + adl_dis, data = att[obs4 == 1 | event == 1],
               weights = att[obs4 == 1 | event == 1]$sw)
cf <- summary(m_ipw)$coefficients; ci <- confint(m_ipw)
cat("== (1) IPW 加权 Cox M4 ==\n")
for (p in c("NS","ONS","OS")) {
  nm <- paste0("pheno", p)
  cat(sprintf("  %-4s HR=%.3f (%.3f-%.3f) p=%.3f\n", p,
      exp(cf[nm,1]), exp(ci[nm,1]), exp(ci[nm,2]), cf[nm,5]))
}

# IPW-LMM(global)
covars <- mcov[-1]
L <- merge(cog2[, .(ID, ftime = time, y = total)], base, by = "ID")
L <- L[!is.na(y)]
for (v in covars) L <- L[!is.na(get(v))]
wmap <- att[, .(ID, sw)]
L2 <- merge(L, wmap, by = "ID", all.x = TRUE)
L2[is.na(sw), sw := 1]
m_ipwlmm <- lmer(y ~ pheno * ftime + age + ragender + educ4f + marry_bin + region +
                 hrural + rural2 + smokev + drinkl + work + retire + logcons +
                 chronicf + adl_dis + (ftime | ID), data = L2, REML = FALSE,
                 weights = sw, control = lmerControl(optimizer = "bobyqa"))
fe <- fixef(m_ipwlmm); ci <- confint(m_ipwlmm, method = "Wald")
cat("\n== IPW 加权 LMM(global)==\n")
for (p in c("NS","ONS","OS")) {
  n1 <- paste0("pheno", p); n2 <- paste0("pheno", p, ":ftime")
  cat(sprintf("  %-4s 基线 %+.3f (%+.3f,%+.3f) | 下降 %+.4f (%+.3f,%+.3f)\n",
      p, fe[[n1]], ci[n1,1], ci[n1,2], fe[[n2]], ci[n2,1], ci[n2,2]))
}

## ---------- (2) 缺失模式表 ----------
mvars <- c("gripsum","bmi","total_cognition","recall","executive","educ4","marry",
           "region","hrural","rural2","smokev","drinkl","work","retire","hhcperc",
           "adlab_c","cesd10","phy_actb","bl_crp")
miss_tab <- data.table(variable = mvars,
  n_missing = sapply(mvars, function(v) sum(is.na(base[[v]]))),
  pct_missing = sapply(mvars, function(v) round(100*mean(is.na(base[[v]])), 1)))
cat("\n== (2) 缺失模式表(基线,n=12152)==\n"); print(miss_tab)
fwrite(miss_tab, "missingness_table.csv")

## ---------- (3) 样本流程表 ----------
flow2 <- data.table(
  step = c("W1 受访(2011)","年龄>=45","排除:记忆/精神疾病/卒中","BMI 合理(10-60)",
           "握力可用(0-80)",">=1次认知评估(2011-2018)","== 分析样本 ==",
           "LMM 完全病例(global)","基线无障碍(Cox 风险集)","Cox M2 完全病例",
           "Cox M4 完全病例","Fine-Gray 完全病例","+CES-D 完全病例"),
  N = c(17708, 17341, NA, 12528, 12302, 12152, 12152,
        10096, 10324, 10319, 8643, 8643, 8583))
cat("\n== (3) 样本流程表 ==\n"); print(flow2)
fwrite(flow2, "flow_table.csv")

## ---------- (4) 体力活动亚组 ----------
svpa <- sv[complete.cases(sv[, ..mcov]) & !is.na(phy_actb)]
m_pa <- coxph(Surv(t, event) ~ pheno + age + ragender + educ4f + marry_bin +
              region + hrural + rural2 + smokev + drinkl + work + retire +
              logcons + chronicf + adl_dis + phy_actb, data = svpa)
cf <- summary(m_pa)$coefficients; ci <- confint(m_pa)
cat(sprintf("\n== (4) 体力活动亚组 Cox(N=%d,事件=%d)==\n", m_pa$n, m_pa$nevent))
for (p in c("NS","ONS","OS")) {
  nm <- paste0("pheno", p)
  cat(sprintf("  %-4s HR=%.3f (%.3f-%.3f) p=%.3f\n", p,
      exp(cf[nm,1]), exp(ci[nm,1]), exp(ci[nm,2]), cf[nm,5]))
}
cat("== 05c 完成 ==\n")
