# =============================================================
# 07_gap_analyses.R — 补齐剩余计算缺口(2026-11-19)
#  A. m3: 慢病计数剔除卒中项后是否不变
#  B. m1/R1: 增量价值 — BMI-only vs BMI+握力 vs 表型(LRT/C-index/NRI)
#  C. M10: BH-FDR 主检验族校正(表2A/2B/3)
#  D. M10: 实践效应敏感性(既往测评次数协变量)
#  E. M3: 表型转移矩阵(W1→W3)+ 时变表型 Cox(start-stop)
#  F. m9: 三阶交互(表型×时间×亚组)系数 + 95%CI
#  G. M6: 流程表清理(统一版本)
# =============================================================
suppressMessages({library(data.table); library(lme4); library(survival)})
setwd("/Users/liyanjiao/Documents/ch/修稿_Frontiers/pipeline")
load("derived_corrected.RData")   # base, cog, cog2, dinfo, norms
sv15 <- readRDS("sv_imp15.rds")   # 修正结局事件数据(ID,event,t)
out <- capture.output({

base[, pheno   := factor(pheno, levels = c("NONS","NS","ONS","OS"))]
base[, educ4f  := factor(educ4, levels = c(1,2,3,4))]
base[, marry_bin := fifelse(marry == 1, 1L, 0L)]
base[, chronicf := factor(chronic, levels = c("0","1","2+"))]

cat("\n########## A. m3: 慢病计数与卒中 ##########\n")
cn2 <- base[, rowSums(cbind(hibpe, dyslipe, diabe, cancre, lunge,
                            hearte, livere, kidneye, digeste, asthmae) == 1, na.rm = TRUE)]
cat("base 内 stroke==1 人数:", sum(base$stroke == 1, na.rm = TRUE),
    "| stroke NA 人数:", sum(is.na(base$stroke)), "\n")
cat("含卒中计数 与 剔除卒中计数 完全相同的人数:",
    sum(base$chronic_n == cn2), "/", nrow(base), "\n")
cat("计数分布交叉表(行=含卒中,列=剔除卒中):\n")
print(table(base$chronic_n, cn2))

cat("\n########## B. m1: 增量价值分析(Cox,修正结局) ##########\n")
sv <- merge(sv15, base, by = "ID")
f_main <- "age + ragender + educ4f + marry_bin + region + hrural + rural2 + smokev + drinkl + work + retire + logcons + chronicf + adl_dis"
sv[, ow_cat := fifelse(bmi >= 24, 1L, 0L)]
sv[, sarc_cat := fifelse((ragender == 1 & grip < 28) | (ragender == 0 & grip < 18), 1L, 0L)]
m_bmi  <- coxph(as.formula(paste("Surv(t, event) ~ ow_cat +", f_main)), data = sv, x = TRUE)
m_both <- coxph(as.formula(paste("Surv(t, event) ~ ow_cat + sarc_cat +", f_main)), data = sv, x = TRUE)
m_ph   <- coxph(as.formula(paste("Surv(t, event) ~ pheno +", f_main)), data = sv, x = TRUE)
for (nm in c("m_bmi","m_both","m_ph")) {
  m <- get(nm); s <- summary(m)
  cat(sprintf("%-7s N=%d 事件=%d C-index=%.4f AIC=%.1f\n",
      nm, m$n, m$nevent, as.numeric(s$concordance[1]), AIC(m)))
}
lrt1 <- anova(m_bmi, m_both, test = "LR"); lrt2 <- anova(m_bmi, m_ph, test = "LR")
cat("\nLRT BMI-only vs BMI+握力:\n"); print(lrt1)
cat("\nLRT BMI-only vs 四表型:\n"); print(lrt2)
cat("\nBMI+握力模型系数(HR, 95%CI):\n")
print(exp(cbind(coef(m_both), confint(m_both)))[c("ow_cat","sarc_cat"),])

## NRI(生存数据,加入连续 bmi+grip 后)
cat("\n")
tryCatch({
  library(nricens)
  set.seed(20261)
  nri <- nricens(time = sv$t, event = sv$event,
                 z.base = as.matrix(model.matrix(m_bmi)[, -1]),
                 z.new = as.matrix(sv[, .(bmi, grip)]),
                 mdl.std = m_bmi, t0 = 5, niter = 1000)
  cat("NRI(5 年,加入连续 BMI+握力):\n")
  print(round(nri$nri, 4))
}, error = function(e) cat("[NRI 计算失败/未安装:", conditionMessage(e), "— C-index/LRT 已足够]\n"))

cat("\n########## C. M10: BH-FDR 主检验族 ##########\n")
pfromt <- function(t) 2*pnorm(-abs(t))   # lmer 系数表无 P 列,用正态近似(大样本)
fam <- list()
for (yn in c("global","episodic","mental")) {
  m <- readRDS(paste0("fit_lmm_", yn, "_educ4.rds"))
  cf <- as.data.frame(summary(m)$coefficients)
  ci <- confint(m, method = "Wald")
  for (p in c("NS","ONS","OS")) {
    nm1 <- paste0("pheno", p); nm2 <- paste0("pheno", p, ":ftime")
    fam$baseline <- rbind(fam$baseline, data.table(outcome = yn, pheno = p,
      est = cf[nm1, "Estimate"], p = pfromt(cf[nm1, "t value"])))
    fam$decline <- rbind(fam$decline, data.table(outcome = yn, pheno = p,
      est = cf[nm2, "Estimate"], p = pfromt(cf[nm2, "t value"])))
  }
}
cf4 <- as.data.frame(summary(m_ph)$coefficients); ci4 <- confint(m_ph)
fam$cox <- rbindlist(lapply(c("NS","ONS","OS"), function(p) data.table(
  pheno = p, HR = exp(cf4[paste0("pheno",p), "coef"]),
  lo = exp(ci4[paste0("pheno",p),1]), hi = exp(ci4[paste0("pheno",p),2]),
  p = cf4[paste0("pheno",p), "Pr(>|z|)"])))
for (k in names(fam)) { d <- fam[[k]]; d[, q := p.adjust(p, method = "BH")]; fam[[k]] <- d }
for (k in names(fam)) { cat(sprintf("\n--- 族:%s ---\n", k)); print(fam[[k]], digits = 3) }

cat("\n########## D. M10: 实践效应敏感性 ##########\n")
cog2[, n_prev := rowid(ID) - 1L]   # 该次评估之前的测评次数(0/1/2/3)
covars <- c("age","ragender","educ4f","marry_bin","region","hrural","rural2",
            "smokev","drinkl","work","retire","logcons","chronicf","adl_dis")
for (yn in c("global","episodic")) {
  yv <- switch(yn, global = "total", episodic = "recall")
  L <- merge(cog2[, .(ID, ftime = time, y = get(yv), n_prev)], base, by = "ID")
  L <- L[!is.na(y)]; for (v in covars) L <- L[!is.na(get(v))]
  m <- lmer(y ~ pheno*ftime + n_prev + age + ragender + educ4f + marry_bin + region + hrural +
            rural2 + smokev + drinkl + work + retire + logcons + chronicf + adl_dis +
            (ftime|ID), data = L, REML = FALSE, control = lmerControl(optimizer = "bobyqa"))
  cf <- as.data.frame(summary(m)$coefficients); ci <- confint(m, method = "Wald")
  cat(sprintf("\n[%s + 实践效应协变量] N行=%d 人=%d | n_prev β=%.3f (%.3f,%.3f) p=%.3g\n",
      yn, nrow(L), uniqueN(L$ID), cf["n_prev","Estimate"], ci["n_prev",1], ci["n_prev",2],
      pfromt(cf["n_prev","t value"])))
  for (p in c("NS","ONS","OS")) {
    nm <- paste0("pheno", p, ":ftime")
    cat(sprintf("  %-4s 下降差 %+.4f (%+.3f,%+.3f) p=%.3g\n", p,
        cf[nm,"Estimate"], ci[nm,1], ci[nm,2], pfromt(cf[nm,"t value"])))
  }
}

cat("\n########## E. M3: 表型转移 + 时变表型 Cox ##########\n")
dt <- fread("/Users/liyanjiao/Documents/ch/charls.csv")
setnames(dt, sub(" [(].*[)]$", "", names(dt)))
dt[, ID := as.character(ID)]
wtime <- c(`1`=0, `2`=2, `3`=4, `4`=7); dt[, time := wtime[as.character(wave)]]
ids <- base$ID
pw <- dt[ID %in% ids & wave <= 4, .(ID, wave, time, gripsum, bmi, ragender)]
pw <- pw[!is.na(gripsum) & !is.na(bmi)]
pw[, sarc_w := (ragender == 1 & gripsum < 28) | (ragender == 0 & gripsum < 18)]
pw[, pheno_w := fcase(bmi < 24 & !sarc_w, "NONS", bmi < 24 & sarc_w, "NS",
                      bmi >= 24 & !sarc_w, "ONS", default = "OS")]
cat("逐波握力+BMI 可用人数(分析样本内):\n")
print(pw[, .(n = uniqueN(ID)), by = wave])
pw1 <- pw[wave == 1, .(ID, p1 = pheno_w)]
tr12 <- merge(pw1, pw[wave == 2, .(ID, p2 = pheno_w)], by = "ID")
tr13 <- merge(pw1, pw[wave == 3, .(ID, p3 = pheno_w)], by = "ID")
cat(sprintf("\nW1→W3(2011→2015) 双波均有测量: %d 人\n", nrow(tr13)))
m13 <- table(tr13$p1, tr13$p3)
print(m13)
cat("\n行百分比(W1→W3):\n"); print(round(prop.table(m13, 1)*100, 1))
cat(sprintf("\n表型不变比例(W1→W3): %.1f%%\n", 100*sum(diag(m13))/sum(m13)))

## 时变表型 Cox(start-stop):每波区间用当波表型(末次观测结转)
setorder(pw, ID, wave)
setkey(pw, ID)
pw[, pheno_l := shift(pheno_w), by = ID]
pw[wave == 1, pheno_l := pheno_w]
svt <- merge(sv15[, .(ID, event, te = t)], base[, .(ID)], by = "ID")
build_tv <- function(d) {
  rows <- vector("list", nrow(d)); i <- 1
  for (k in seq_len(nrow(d))) {
    pwid <- pw[ID == d$ID[k]]
    if (nrow(pwid) == 0 || max(pwid$time) <= 0) next
    exit <- d$te[k]; ev <- d$event[k]
    for (r in seq_len(nrow(pwid))) {
      st <- pwid$time[r]
      en <- if (r < nrow(pwid)) pwid$time[r + 1] else Inf
      en <- min(en, exit)
      if (st >= en) next
      ev_r <- as.integer(ev == 1 & exit > st & exit <= en)
      rows[[i]] <- data.table(ID = d$ID[k], start = st, stop = en, ev = ev_r,
                              ph = pwid$pheno_l[r]); i <- i + 1
      if (ev_r == 1 || en >= exit) break
    }
  }
  rbindlist(rows[seq_len(i - 1)])
}
tv <- build_tv(svt)
tv[, ph := factor(ph, levels = c("NONS","NS","ONS","OS"))]
tv <- merge(tv, base[, .(ID, age, ragender, educ4f, marry_bin, region, hrural, rural2,
                         smokev, drinkl, work, retire, logcons, chronicf, adl_dis)], by = "ID")
mtv <- coxph(Surv(start, stop, ev) ~ ph + age + ragender + educ4f + marry_bin + region +
             hrural + rural2 + smokev + drinkl + work + retire + logcons + chronicf + adl_dis,
             data = tv)
cat(sprintf("\n时变表型 Cox:start-stop 行=%d 人=%d 事件=%d\n",
    nrow(tv), uniqueN(tv$ID), sum(tv$ev)))
cfv <- as.data.frame(summary(mtv)$coefficients); civ <- confint(mtv)
for (p in c("NS","ONS","OS")) {
  nm <- paste0("ph", p)
  cat(sprintf("  %-4s HR=%.3f (%.3f-%.3f) p=%.3g\n", p,
      exp(cfv[nm,"coef"]), exp(civ[nm,1]), exp(civ[nm,2]), cfv[nm,"Pr(>|z|)"]))
}

cat("\n########## F. m9: 三阶交互系数+95%CI ##########\n")
base[, agegrp3 := fcase(age < 60, "45-59", age < 70, "60-69", default = "70+")]
for (yn in c("global","episodic","mental")) {
  yv <- switch(yn, global = "total", episodic = "recall", mental = "exec")
  L <- merge(cog2[, .(ID, ftime = time, y = get(yv))], base, by = "ID")
  L <- L[!is.na(y)]; for (v in covars) L <- L[!is.na(get(v))]
  subs <- list(list("sex", "ragender", TRUE),
               list("age group", "agegrp3", FALSE),
               list("residence", "hrural", TRUE))
  for (s in subs) {
    Ls <- copy(L)
    if (s[2] == "ragender") { Ls[, sg := factor(ragender)] }
    else if (s[2] == "agegrp3") { Ls[, sg := factor(agegrp3, c("45-59","60-69","70+"))] }
    else { Ls[, sg := factor(hrural)] }
    cv <- if (s[2] == "ragender") setdiff(covars, "ragender") else
          if (s[2] == "hrural")   setdiff(covars, "hrural") else covars
    fml <- paste("y ~ pheno*ftime*sg +", paste(cv, collapse = " + "), "+ (ftime|ID)")
    m <- lmer(fml, data = Ls, REML = FALSE, control = lmerControl(optimizer = "bobyqa"))
    cf <- as.data.frame(summary(m)$coefficients); ci <- confint(m, method = "Wald")
    tn <- grep("^pheno.*:ftime.*:sg$", rownames(cf), value = TRUE)
    cat(sprintf("\n[%s × %s] N行=%d 人=%d\n", yn, s[1], nrow(Ls), uniqueN(Ls$ID)))
    for (nm in tn) cat(sprintf("  %-30s %+.4f (%+.4f,%+.4f) p=%.3g\n",
        nm, cf[nm,"Estimate"], ci[nm,1], ci[nm,2], pfromt(cf[nm,"t value"])))
  }
}

cat("\n########## G. M6: 统一流程表(权威版,与 01_derive 一致) ##########\n")
fl <- data.table(step = c("W1 受访 (2011)","年龄 >= 45","排除: 基线记忆相关疾病","排除: 精神疾病",
                          "排除: 卒中","BMI 合理 (10-60) 且非缺失","握力可用 (0-80)",
                          ">=1 次认知评估 (2011-2018)","= 分析样本","LMM 完全病例 (global)",
                          "Cox 风险集 (基线无损害)","Cox M2 完全病例","Cox M4 完全病例",
                          "Fine-Gray 模型","+CES-D 敏感性模型"),
                 N = c(17708, 17060, 16738, 16524, 16120, 12528, 12302, 12152, 12152,
                       10096, 10324, 10319, 8643, 8643, 8583))
print(fl)
fwrite(fl, "flow_table_clean.csv")
fwrite(fam$baseline[order(outcome, pheno)], "fdr_baseline.csv")
fwrite(fam$decline[order(outcome, pheno)], "fdr_decline.csv")
fwrite(fam$cox, "fdr_cox.csv")
saveRDS(list(lrt_bmi_grip = lrt1, lrt_bmi_pheno = lrt2,
             c_bmi = as.numeric(summary(m_bmi)$concordance[1]),
             c_both = as.numeric(summary(m_both)$concordance[1]),
             c_ph = as.numeric(summary(m_ph)$concordance[1]),
             both_coefs = exp(cbind(coef(m_both), confint(m_both))),
             transitions = m13, trans_pct = round(prop.table(m13,1)*100,1),
             tv_cox = list(N = nrow(tv), nperson = uniqueN(tv$ID),
                           HR = exp(cfv[,"coef"]), CI = exp(civ))),
        "sv_incremental.rds")
})
writeLines(out, "07_gap_report.txt")
cat("\n== 07_gap_report.txt 已保存 ==\n")
