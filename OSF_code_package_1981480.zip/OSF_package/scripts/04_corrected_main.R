# =============================================================
# 04_corrected_main.R — 修正版主分析
# 修正1:教育协变量 = raeduc_c 四分类(无/小学/初中/高中+)
# 修正2:结局 = 年龄×教育分层 norm(mean−1.5SD) 下的认知障碍
# 输出:修正切点表 / 基线患病率 / 修正版LMM / 修正版Cox(M2+M4)
#       逆转比例 / 连续两波确认SA / 标准化效应量
# =============================================================
suppressMessages({library(data.table); library(lme4); library(survival)})
setwd("/Users/liyanjiao/Documents/ch/修稿_Frontiers/pipeline")
load("derived.RData")

base[, pheno   := factor(pheno, levels = c("NONS","NS","ONS","OS"))]
base[, educ4f  := factor(educ4, levels = c(1,2,3,4))]          # 修正版教育
base[, educ_bin := fifelse(educ4 %in% c(1,2), "lep", "gem")]   # ≤小学 / ≥初中
base[, agegrp  := fcase(age < 60, "45-59", age < 70, "60-69", default = "70+")]
base[, marry_bin := fifelse(marry == 1, 1L, 0L)]
base[, chronicf := factor(chronic, levels = c("0","1","2+"))]

## ---------- 1. 分层 norm 切点(基线横断面) ----------
w1c <- merge(cog[wave == 1, .(ID, t0 = total)], base[, .(ID, agegrp, educ_bin)], by = "ID")
norms <- w1c[!is.na(t0) & !is.na(agegrp) & !is.na(educ_bin),
             .(n = .N, mean = mean(t0), sd = sd(t0),
               cut15 = mean(t0) - 1.5*sd(t0), cut10 = mean(t0) - 1.0*sd(t0)),
             by = .(agegrp, educ_bin)][order(agegrp, educ_bin)]
cat("== 修正切点(norm−1.5SD,按 年龄×教育 分层)==\n"); print(norms, digits = 3)

base <- merge(base, norms[, .(agegrp, educ_bin, cut15, cut10)],
              by = c("agegrp","educ_bin"), all.x = TRUE)

## ---------- 2. 全波障碍标记(修正版) ----------
cog2 <- merge(cog[, .(ID, wave, time, total, recall, exec)],
              base[, .(ID, cut15, cut10)], by = "ID", all.x = TRUE)
cog2[, imp15 := total < cut15]
cog2[, imp10 := total < cut10]

b1 <- cog2[wave == 1]
cat(sprintf("\n基线患病率:−1.5SD = %d (%.1f%%) | −1.0SD = %d (%.1f%%) | 原稿切点 = 4163 (34.3%%)\n",
    sum(b1$imp15, na.rm=TRUE), 100*mean(b1$imp15, na.rm=TRUE),
    sum(b1$imp10, na.rm=TRUE), 100*mean(b1$imp10, na.rm=TRUE)))

## ---------- 3. 逆转比例(Major 2b) ----------
setkey(cog2, ID, wave)
cog2[, next_imp15 := shift(imp15, 1, type = "lead"), by = ID]
tr <- cog2[imp15 == TRUE & !is.na(next_imp15)]
cat(sprintf("\n逆转比例(障碍→下一波恢复): %d/%d = %.1f%%\n",
    sum(tr$next_imp15 == FALSE, na.rm = TRUE), nrow(tr),
    100*mean(tr$next_imp15 == FALSE, na.rm = TRUE)))

## ---------- 4. 修正版 LMM(educ4 协变量) ----------
covars <- c("age","ragender","educ4f","marry_bin","region","hrural","rural2",
            "smokev","drinkl","work","retire","logcons","chronicf","adl_dis")
mk_long <- function(yvar) {
  L <- merge(cog2[, .(ID, ftime = time, y = get(yvar))], base, by = "ID")
  L <- L[!is.na(y)]
  for (v in covars) L <- L[!is.na(get(v))]
  L
}
fit_lmm <- function(L)
  lmer(y ~ pheno * ftime + age + ragender + educ4f + marry_bin + region + hrural +
       rural2 + smokev + drinkl + work + retire + logcons + chronicf + adl_dis +
       (ftime | ID), data = L, REML = FALSE,
       control = lmerControl(optimizer = "bobyqa"))

sd_y <- c(global = sd(base$total_cognition, na.rm = TRUE),
          episodic = sd(base$recall, na.rm = TRUE),
          mental = sd(base$executive, na.rm = TRUE))

cat("\n== 修正版 LMM(含标准化效应量)==\n")
lmm_res <- list()
for (yn in c("global","episodic","mental")) {
  yv <- switch(yn, global = "total", episodic = "recall", mental = "exec")
  L <- mk_long(yv); m <- fit_lmm(L); fe <- fixef(m); ci <- confint(m, method = "Wald")
  cat(sprintf("\n[%s] N行=%d 人=%d | 基线SD=%.2f | NONS年下降=%.3f\n",
      yn, nrow(L), uniqueN(L$ID), sd_y[yn], fe[["ftime"]]))
  for (p in c("NS","ONS","OS")) {
    nm1 <- paste0("pheno", p); nm2 <- paste0("pheno", p, ":ftime")
    cat(sprintf("  %-4s 基线 %+.3f (%+.3f,%+.3f) | 下降 %+.4f (%+.3f,%+.3f) | 相当于基线SD %.2f | 相当年老化 %.1f年\n",
        p, fe[[nm1]], ci[nm1,1], ci[nm1,2], fe[[nm2]], ci[nm2,1], ci[nm2,2],
        fe[[nm1]]/sd_y[yn], fe[[nm1]]/abs(fe[["ftime"]])))
  }
  lmm_res[[yn]] <- list(fe = fe, ci = ci)
  saveRDS(m, paste0("fit_lmm_", yn, "_educ4.rds"))
}

## ---------- 5. 修正版 Cox ----------
mk_surv <- function(impvar, confirm = FALSE) {
  w1 <- cog2[wave == 1, .(ID, imp0 = get(impvar))]
  risk <- base[ID %in% w1[is.na(imp0) | imp0 == FALSE, ID]]
  ev <- data.table(ID = character(), event = integer(), t = numeric())
  for (id in risk$ID) {
    w <- cog2[ID == id & wave >= 2 & !is.na(get(impvar))]
    prev <- 0; e <- 0L; te <- 0
    waves_all <- cog2[ID == id]
    last_t <- waves_all[wave == 1, max(time, 0)]
    for (r in seq_len(nrow(w))) {
      if (as.logical(w[[impvar]][r])) {
        ok <- TRUE
        if (confirm) {
          nw <- w[wave > w$wave[r] & !is.na(get(impvar))]
          if (nrow(nw) > 0 && !as.logical(nw[[impvar]][1])) ok <- FALSE
        }
        if (ok) { e <- 1L; te <- (last_t + w$time[r])/2; break }
      }
      last_t <- w$time[r]
    }
    if (e == 0) {
      obs <- cog2[ID == id & !is.na(total)]
      te <- if (nrow(obs)) max(obs$time, 0) else 0
    }
    ev <- rbind(ev, data.table(ID = id, event = e, t = te))
  }
  merge(risk[, .(ID)], ev, by = "ID")[t > 0]
}

run_cox <- function(sv) {
  sv <- merge(sv, base, by = "ID")
  m2 <- coxph(Surv(t, event) ~ pheno + age + ragender + educ4f + marry_bin +
              region + hrural + smokev + drinkl, data = sv)
  m4 <- coxph(Surv(t, event) ~ pheno + age + ragender + educ4f + marry_bin +
              region + hrural + rural2 + smokev + drinkl + work + retire +
              logcons + chronicf + adl_dis, data = sv)
  for (mn in c("m2","m4")) {
    m <- get(mn); cf <- summary(m)$coefficients; ci <- confint(m)
    cat(sprintf("  [%s] N=%d 事件=%d (%.1f%%)\n", mn, m$n, m$nevent, 100*m$nevent/m$n))
    for (p in c("NS","ONS","OS")) {
      nm <- paste0("pheno", p)
      cat(sprintf("    %-4s HR=%.3f (%.3f-%.3f) p=%.3f\n", p,
          exp(cf[nm,1]), exp(ci[nm,1]), exp(ci[nm,2]), cf[nm,5]))
    }
    cat(sprintf("    年龄 HR=%.3f\n", exp(cf["age",1])))
  }
}

cat("\n== 修正版 Cox(−1.5SD 结局)==\n")
sv15 <- mk_surv("imp15"); cat(sprintf("风险集 N=%d\n", nrow(sv15))); run_cox(sv15)
saveRDS(sv15, "sv_imp15.rds")

cat("\n== SA:连续两波确认(−1.5SD)==\n")
sv15c <- mk_surv("imp15", confirm = TRUE); cat(sprintf("风险集 N=%d\n", nrow(sv15c))); run_cox(sv15c)
saveRDS(sv15c, "sv_imp15_confirm.rds")

cat("\n== 完成 ==\n")
