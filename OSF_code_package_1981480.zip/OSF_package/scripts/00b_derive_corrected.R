# 00b_derive_corrected.R — 生成修正版派生数据(供 05+ 系列使用)
suppressMessages(library(data.table))
setwd("/Users/liyanjiao/Documents/ch/修稿_Frontiers/pipeline")
load("derived.RData")

base[, educ4f   := factor(educ4, levels = c(1,2,3,4))]
base[, educ_bin := fifelse(educ4 %in% c(1,2), "lep", "gem")]
base[, agegrp   := fcase(age < 60, "45-59", age < 70, "60-69", default = "70+")]

w1c <- merge(cog[wave == 1, .(ID, t0 = total)], base[, .(ID, agegrp, educ_bin)], by = "ID")
norms <- w1c[!is.na(t0), .(n = .N, cut15 = mean(t0) - 1.5*sd(t0), cut10 = mean(t0) - sd(t0)),
             by = .(agegrp, educ_bin)]
base <- merge(base, norms[, .(agegrp, educ_bin, cut15, cut10)], by = c("agegrp","educ_bin"), all.x = TRUE)

cog2 <- merge(cog[, .(ID, wave, time, total, recall, exec)], base[, .(ID, cut15, cut10)], by = "ID")
cog2[, imp15 := total < cut15]
cog2[, imp10 := total < cut10]

dinfo[, td := dyear + (dmonth - 0.5)/12 - 2011.5]
save(base, cog2, cog, dinfo, norms, file = "derived_corrected.RData")
cat("derived_corrected.RData 已保存(含 cut15/cut10/imp15/imp10/norms)\n")
print(norms[order(agegrp, educ_bin)], digits = 3)
